l'expression: htmlDocIdGet() est une fonction qui 
remplacera document.getElementById(id) 
et qui prendra l'id en paramètre