/*Sélectionne le *premier* paragraphe du document et 
change son text avec la propriété textContent*/
document.querySelector('p').textContent = ' Hello javascript';
//NB::: 
/*ici quand j'utilise +=,l'ancien contenu du 
paragraphe n'est pas remplacé mais est concaténé
avec le nouveau contenu,donc += ajoute du contenu
dans un élément avec la sélection document.(...).
alors sera parfois utile(si on n'aimerait plutot ajouter que changer)
et parfois non(si on aimerait changer qu'ajouter)*/
//document.querySelector('div').querySelector('p').textContent = 'c\'est le premier paragraphe de la div'

/*selectionne le premier élément du document avec
class='bleu'*/
//si on souhaite utiliser querySelector() pour les élément avec id,on met # avant l'id(#p1 par exemple)
document.querySelector('p.bleu').style.color = 'blue';

//sélectionner tous les paragraphes du document
document.querySelectorAll('p')

/*on utilise forEach() sur l'objet NodeList pour 
rajouter du texte dans chaque paragraphe du document*/

document.querySelectorAll('p').forEach((name,index) => name.textContent += ' paragraphe numéro : ' + index)

//**Accéder à un élément en fonction de la valeur de son attribut id**\\

/* La méthode getElementById() est un moyen simple d’accéder à un élément en particulier 
(si celui-ci possède un id) puisque les id sont uniques dans un document. */

//getElementById()

//**Accéder à un élément en fonction de la valeur de son attribut class**\\

/* En utilisant la méthode getElementsByClassName() avec un objet Document, la recherche 
des éléments se fera dans tout le document. En l’utilisant avec un objet Element, la 
recherche se fera dans l’élément en question. */

//getElementsByClassName()

//**Accéder à un élément en fonction de son identité**\\

/* La méthode getElementsByTagName() permet de sélectionner des éléments en fonction 
de leur nom et renvoie un objet HTMLCollection qui consiste en une liste d’éléments 
correspondant au nom de balise passé en argument. A noter que cette liste est mise à 
jour en direct (ce qui signifie qu’elle sera modifiée dès que l’arborescence DOM le sera). */

//getElementsByTagName()

/* Accéder à un élément en fonction de son attribut name
Finalement, l’interface Document met également à notre disposition la 
méthode getElementsByName() qui renvoie un objet NodeList contenant la liste des 
éléments portant un attribut name avec la valeur spécifiée en argument sous forme d’objet. */

//On va pouvoir utiliser cette méthode pour sélectionner des éléments de formulaire par exemple.

//getElementsByName()

//**Accéder directement à des éléments particuliers avec les propriétés de Document**\\

/* Les propriétés qui vont le plus nous intéresser 
ici sont les suivantes : */
//• La propriété body qui retourne le nœud représentant l’élément body ;

//• La propriété head qui retourne le nœud représentant l’élément head ;

//• La propriété links qui retourne une liste de tous les éléments a ou area possédant un href avec une valeur ;
//• La propriété title qui retourne le titre (le contenu de l’élément title) du document ou permet de le redéfinir ;
//• La propriété url qui renvoie l’URL du document sous forme de chaine de caractères ;
//• La propriété scripts qui retourne une liste de tous les éléments script du document ;
//• La propriété cookie qui retourne la liste de tous les cookies associés au document sous forme de chaine de caractères ou qui permet de définir un nouveau cookie.


//***Accéder au contenu des éléments et le modifier***\\

/* Pour récupérer le contenu d’un élément ou le modifier, nous allons pouvoir utiliser l’une 
des propriétés suivantes : */
//• La propriété innerHTML de l’interface Element permet de récupérer ou de redéfinir la syntaxe HTML interne à un élément ;
//• La propriété outerHTML de l’interface Element permet de récupérer ou de redéfinir l’ensemble de la syntaxe HTML interne d’un élément et de l’élément en soi ;
//• La propriété textContent de l’interface Node représente le contenu textuel d’un nœud et de ses descendants. On utilisera cette propriété à partir d’un objet Element ;
//• La propriété innerText de l’interface Node représente le contenu textuel visible sur le document final d’un nœud et de ses descendants. On utilisera cette propriété à partir d’un objet Element.






















































