document.querySelector('h1').outerHTML = '<p>salut</p>'

document.querySelector('p').style.color = 'red'

document.querySelector('p').innerHTML = 'ici c\'est javascript'

document.querySelector('p').textContent = 'frontend'

document.querySelector('p').innerHTML +='<br>' + document.querySelector('p').innerText


