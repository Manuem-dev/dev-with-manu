//***Gestion d’évènements***\\

//**Définir des gestionnaires d’évènements**\\

//•On peut utiliser la méthode addEventListener() (recommandé.
//• On peut utiliser des attributs HTML de type évènement (non recommandé) ;
//• On peut utiliser des propriétés JavaScript liées aux évènements ;

function onclick(){
  alert('clicked')
}
//*Utiliser la méthode addEventListener() pour gérer un évènement*\\

document.querySelector('#btn').addEventListener('click',() => alert('est clické') );

//affiche cliked quand on click
document.querySelector('#btn0').addEventListener('click',onclick);



/* On va passer deux arguments à cette méthode : le nom d’un évènement qu’on souhaite 
prendre en charge ainsi que le code à exécuter (qui prendra souvent la forme d’une 
fonction) en cas de déclenchement de cet évènement.


Notez qu’on va par ailleurs pouvoir utiliser la méthode addEventListener() pour réagir 
plusieurs fois et de façon différente à un même évènement ou pour réagir à différents 
évènements à partir de différents ou d’un même objet Element. */

//*Supprimer un gestionnaire d’évènements avec removeEventListener()*\\

/* La méthode removeEventListener() de l’interface EventTarget va nous permettre de 
supprimer un gestionnaire d’évènement déclaré avec addEventListener().

Pour cela, il va suffire de passer en argument le type d’évènement ainsi que le nom de la 
fonction passée en argument de addEventListener(). */
//annule l'évènement d'affichage de clicked quand on clique
document.querySelector('#btn0').removeEventListener('click',onclick);
//NB: ici il faut le nom de la fonction plutôt qu'une fonction directe


/* La méthode removeEventListener() va s’avérer utile lorsqu’on voudra retirer un 
gestionnaire d’évènement selon certains cas comme par exemple dans la situation où un 
autre évènement s’est déjà déclenché. */

//***Propagation des évènements***\\

//**Les phases de capture et de bouillonnement**\\
//phase de capture:descend le DOM jusqu'à l'élément cible
//phase de bouillonnement:remonte le DOM à partir de l'élément cible

//**Choisir la phase de déclenchement d’un gestionnaire d’évènements**\\

/* Pour choisir dans quelle phase un gestionnaire d’évènement doit se déclencher, nous 
allons pouvoir passer un troisième argument booléen à la méthode addEventListener().

Par défaut, la valeur de cet argument est false ce qui indique que le gestionnaire 
d’évènement doit ignorer la phase de capture. Pour lui demander de réagir à la phase de 
capture, on va donc devoir lui passer la valeur true. */


//***Empêcher la propagation d’évènements***\\

//**Stopper la propagation d’un évènement**\\

/* Pour stopper la propagation d’un évènement, on va pouvoir utiliser la 
méthode stopPropagation() de l’interface Event. Cette méthode va stopper la propagation 
d’un évènement après qu’un gestionnaire d’évènement (gérant l’évènement en question) 
ait été atteint. */

/* Cela signifie que si la phase de bouillonnement est choisie, le gestionnaire le plus proche 
de l’élément cible de l’évènement sera exécuté et les gestionnaires de ce même 
évènement attachés aux éléments parents seront ignorés. */

/* Si on ne souhaite véritablement exécuter qu’un seul gestionnaire d’un évènement et 
ignorer tous les autres, on utilisera plutôt la méthode stopImmediatePropagation() de cette 
même interface.
Dans le cas où on utilise stopImmediatePropagation(), seul le premier gestionnaire de 
l’évènement attaché au premier élément atteint sera exécuté */

/* Stopper la propagation d’un évènement va pouvoir s’avérer très pratique dans le cas où 
nous avons plusieurs gestionnaires d’évènements pour le même évènement attachés à 
différents éléments dans la page et où on souhaite n’exécuter que le gestionnaire le plus 
proche de l’élément cible de l’évènement. */

//affiche d'abord celui du p1 et ensuite de son parent d1(le phénomène de propagation);
document.querySelector('#d1').addEventListener('click',() => alert('hello d1'));
document.querySelector('#p1').addEventListener('click',() => alert('hello p1'));

//**Prévenir le comportement de base d’un évènement**\\

/* Nous allons également pouvoir faire en sorte que l’action par défaut d’un évènement ne 
soit pas prise en compte par le navigateur. Pour faire cela, nous allons utiliser la 
méthode preventDefault() de l’interface Event. */

/* Cela va notamment s’avérer très intéressant pour prévenir l’envoi d’un formulaire mal 
rempli. */

/* En effet, lorsqu’un utilisateur souhaite envoyer un formulaire, il clique sur un bouton 
d’envoi. L’action associée par défaut à ce clic est l’envoi du formulaire. La 
méthode preventDefault() va nous permettre de neutraliser cette action par défaut (l’envoi 
du formulaire). On va vouloir faire ça dans le cas où on s’aperçoit que l’utilisateur a mal 
rempli le formulaire par exemple. */

document.getElementById('prenom').addEventListener('click',prev)
function prev(e){
  alert('No');
  e.preventDefault()
}
























