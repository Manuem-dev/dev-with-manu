//**L’élément HTML input : base du convertisseur**\\

/* élément HTML input (élément de type champ de formulaire) est un élément HTML qui 
permet aux visiteurs de rentrer et de nous envoyer des données. C’est l’élément 
généralement privilégié et utilisé lorsqu’on souhaite dynamiser notre site et “dialoguer” 
avec les utilisateurs. */


//**Création du convertisseur en JavaScript**\\

//poids

//fonction de convertion
function convert(id,value){
  if (id == 'gramme'){
    if ((typeof document.getElementById('gramme').value) !=  'string' ){
      alert('veuillez entrer un nombre')
    } else{
      document.getElementById('kilo').value = value/1000;
    }
  } else if (id == 'kilo'){
    if ((typeof document.getElementById('kilo').value) != 'string' ){
      alert('veuillez entrer un nombre')
    } else{
      document.getElementById('gramme').value = value*1000;
    }
  }
}


//this sera utilisé pour l'objet élément en considérant ses propriétés id et value

document.getElementById('gramme').addEventListener('input',function(){convert(this.id,this.value)});

document.getElementById('kilo').addEventListener('input',function(){convert(this.id,this.value)});

//distance

//fonction de convertion
function convertM(id,value){
  if (id == 'km'){
    if ((typeof document.getElementById('km').value) !=  'string' ){
      alert('veuillez entrer un nombre')
    } else{
      let m = document.getElementById('m').value = value*1000;
      let cm = document.getElementById('cm').value = m * 1000;
      document.getElementById('mm').value = cm * 1000;
    }
  } else if (id == 'm'){
    if ((typeof document.getElementById('m').value) != 'string' ){
      alert('veuillez entrer un nombre')
    } else{
      document.getElementById('km').value = value/1000;
      
      document.getElementById('cm').value = value * 100;
      
      document.getElementById('mm').value = value * 1000;
    }
  } else if (id == 'cm'){
    if ((typeof document.getElementById('cm').value) != 'string' ){
      alert('veuillez entrer un nombre')
    } else{
      document.getElementById('m').value = value / 100;      
      
      document.getElementById('km').value = document.getElementById('m').value/1000;

      document.getElementById('mm').value = value * 10;
    }
  } else if (id == 'mm') {
  if ((typeof document.getElementById('mm').value) != 'string') {
    alert('veuillez entrer un nombre')
  } else {
    document.getElementById('m').value = value / 1000;
    document.getElementById('km').value = document.getElementById('m').value/ 1000;
    
    document.getElementById('cm').value = value / 10;
  }
}
}


//this sera utilisé pour l'objet élément en considérant ses propriétés id et value

document.getElementById('km').addEventListener('input',function(){convertM(this.id,this.value)});

document.getElementById('m').addEventListener('input',function(){convertM(this.id,this.value)});

document.getElementById('cm').addEventListener('input',function(){convertM(this.id,this.value)});

document.getElementById('mm').addEventListener('input',function(){convertM(this.id,this.value)});





