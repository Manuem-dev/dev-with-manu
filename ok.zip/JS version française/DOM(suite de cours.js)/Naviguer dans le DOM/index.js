//**Accéder au parent ou à la liste des enfants d’un nœud**\\

//la oropriété parentNode renvoie le parent du nœud ou null si le nœud ne possède pas de parent.
//la propriété childNodes renvoie elle une liste sous forme de tableau des nœuds enfants de l’élément donné. 
//la propriété children ne permet de récupérer que les nœuds enfants éléments
//la propriété parentElement ne permet d'accéder au parent que dans le cas où celui-ci est un nœud Element


//on accède à l'élément(au noeud) parent de p1 qui est body
document.getElementById('p1').parentNode.style.backgroundColor = 'gold';
document.getElementById('p1').parentNode.style.fontSize = '20px';

//on accède à la liste(le tableau créer) des éléments enfants de la div puis aux éléments enfants par leur indice de tableeau
document.getElementById('div').style.backgroundColor = 'yellow'

//on accède au premier enfant de l'élément parent div
document.getElementById('div').childNodes[1].style.fontSize = '12px'
document.getElementById('div').children[1].style.fontSize = '30px'


//**Accéder à un nœud enfant en particulier à partir d’un nœud parent**\\

//La propriété firstChild renvoie le premier nœud enfant direct d’un certain nœud ou null s’il n’en a pas.
//La propriété lastChild renvoie le dernier nœud enfant direct d’un certain nœud ou null s’il n’en a pas.
/* Pour renvoyer le premier et le dernier nœud enfant de type élément seulement d’un certain 
nœud, on utilisera plutôt les propriétés firstElementChild et lastElementChild  */

/*console.log(
  document.body.firstChild,'\n',
  document.body.lastChild,'\n',
  document.body.firstElementChild,'\n',
  document.body.lastElementChild
)
*/
//**Accéder au nœud précédent ou suivant un nœud dans l’architecture DOM**\\

/* La propriété previousSibling de l’interface Node renvoie le nœud précédent un certain 
nœud dans l’arborescence du DOM (en ne tenant compte que des nœuds de même 
niveau) ou null si le nœud en question est le premier.


La propriété nextSibling, au contraire, renvoie elle le nœud suivant un certain nœud dans 
l’arborescence du DOM (en ne tenant compte que des nœuds de même niveau) ou null si 
le nœud en question est le dernier. 


Si on souhaite accéder spécifiquement au nœud élément précédent ou suivant un certain 
nœud, on utilisera plutôt les propriétés previousElementSibling et nextElementSibling du 
mixin NonDocumentTypeChildNode (mixin implémenté par Element).*/

//**Obtenir le nom d’un nœud, son type ou son contenu**\\

/* Lorsqu’on accède à un certain nœud, on voudra généralement obtenir le nom de de nœud, 
savoir ce qu’il contient et connaitre son type. Nous allons pour cela pouvoir utiliser les 
propriétés suivantes de l’interface Node :

• La propriété nodeName qui retourne une chaine de caractères contenant le nom du 
nœud (nom de la balise dans le cas d’un nœud de type Element ou #text dans le 
cas d’un nœud de type Text) ;
• La propriété nodeValue qui renvoie ou permet de définir la valeur du nœud. On 
pourra notamment utiliser cette propriété sur des nœuds #text pour obtenir le texte 
qu’ils contiennent ;
• La propriété nodeType renvoie un entier qui représente le type du nœud (tel que vu 
dans la première leçon de cette partie). */

//***Ajouter, modifier ou supprimer des éléments du DOM***\\

//**Créer de nouveaux nœuds et les ajouter dans l’arborescence du DOM**\\

//*Créer un nœud Element ou un nœud Texte*\\

//la méthode createElement() permet de créer un nouveau élément HTML en Js

//*Insérer un nœud dans le DOM*\\

//Nous pouvons déjà utiliser les méthodes prepend() et append()
/*  Ces 
deux méthodes vont respectivement nous permettre d’insérer un nœud ou du texte avant 
le premier enfant d’un certain nœud ou après le dernier enfant de ce nœud. */

//exemple
let h = document.createElement('h1').textContent = 'hello'
document.body.prepend(h)
document.body.append(document.createElement('p').innerText = 'Javascript')

//**Déplacer un nœud dans le DOM**\\

/* Pour déplacer un nœud dans le DOM, on peut utiliser l’une des 
méthodes appendChild() ou insertBefore() de Node en leur passant en argument un nœud 
qui existe déjà et qui est déjà placé dans le DOM. */

document.body.insertBefore(document.getElementById('p1'),document.body.lastChild)



















































