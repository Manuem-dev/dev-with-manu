document.body.style.backgroundColor = '#33334355';
//***Les classes de caractères***\\

//rôle?
/* Les classes de caractères vont nous permettre de fournir différents choix de 
correspondance pour un caractère en spécifiant un ensemble de caractères qui vont 
pouvoir être trouvés. */

// Pour déclarer une classe de caractères dans notre masque, nous allons utiliser une paire de crochets [ ] qui vont nous permettre de délimiter la classe en question.

let str = "Bonjour,par ici javascript! en plus de python et du HTML5 et CSS3 déjà cernés";

// renvoie un tableau de voyelles trouvées dans str
document.getElementById('p1').innerHTML += '•voyelles trouvées : '+str.match(/[aeiouy]/g)+'<br>';

//cherchera une combinaison des éléments renseignés
document.getElementById('p1').innerHTML +='•combinaison de "e" et de "t" trouvée (et) : '+ str.match(/[e][t]/g) + '<br>';

document.getElementById('p1').innerHTML +='•tableau avec split sur "et" : ' + str.split(/[e][t]/g) + '<br>';

// voir un 'd' suivi d'une voyelle
document.getElementById('p1').innerHTML +="• Toute combinaison de 'd' et d'une voyelle dans str : " + str.match(/d[aeiouy]/g);

//***Les classes de caractères et les méta caractères***\\

str = 'SaLut,vous pouver /contacter/ l\'assistance de ^ShareDem^ au [00-00-00-00]! que du bien! Ah Oui,Du \Super\ bien ';
// '^' permet de nier la classe devant laquele il est placé ie chercher donc les éléments n'appartenant pas à cette classe là(un peu comme !). il doit être placé au début de la classe sinon sera aussi considéré comme à rechercher

document.getElementById('p2').innerHTML += `*autre chose qu'une voyelle : ${str.match(/[^aeiouy]/g)} <br>`; // cherche donc des consonnes

// '\' permet de protéger des caractères comme '/','[]','^'

//NB::: les espaces ' ' sont aussi des caractères
document.getElementById('p2').innerHTML += ` *cherchons des voyelles et un '^' : ${str.match(/[\^aeiouy]/g)} <br>`;//test d'échapement

document.getElementById('p2').innerHTML += ` *cherchons des voyelles et un '^' : ${str.match(/[aei^ouy]/g)} <br>`;//car pas placé au début

//'-' entre deux caractère indique un intervalle. se place toujours entre deux caractères sinon au début et à la fin n'aura pas son sens spécial
document.getElementById('p2').innerHTML += `•Un caractère suivi de 'u' : ${str.match(/[a-z]u/g)} <br>`;//intervalle de classe [-] avec le "-"

document.getElementById('p2').innerHTML += `•Un caractère suivi de 'u' : ${str.match(/[a-zA-Z]u/g)}<br>`;//intervalle de classe [-] avec le "-" avec une combinaison

document.getElementById('p2').innerHTML += `•des 'a','-',et 'z' : ${str.match(/[a\-z]/g)} <br>`;//cherche 'a','-','z' grâce à l'échapement

document.getElementById('p2').innerHTML += `•chiffre,'a' et '-' : ${str.match(/[0-9a-]/g)} <br>`; //un chiffre,'a' et un '-'

document.getElementById('p2').innerHTML += `•De pointe : ${str.match(/[\[\]\/\^0-9]/g)} <br>`; //cherche '[',']','/','^' et un chiffre

//***Les classes de caractères abrégées ou prédéfinies***\\
















