document.body.style.backgroundColor = '#33333355'

//**Présentation des expressions régulières**\\

/* Les expressions régulières sont des schémas ou des motifs utilisés pour effectuer des 
recherches et des remplacements dans des chaines de caractères */

/* Concrètement, les expressions régulières vont nous permettre de vérifier la présence de 
certains caractères ou suites de caractères dans une expression. */

/* En JavaScript, les expressions régulières sont avant tout des objets appartenant à l’objet
global constructeur RegExp. Nous allons donc pouvoir utiliser les propriétés et méthodes 
de ce constructeur avec nos expressions régulières */

//**Création d’une première expressions régulière et syntaxe des Regex**\\

//1ère méthode:
let regex1 = /javascript/;

//2ème méthode:
let regex2 = RegExp('javascript');


//***Recherches et remplacements***\\

//**La méthode match() de l’objet String**\\

//La méthode match() de l’objet String va nous permettre de rechercher la présence de caractères ou de séquences de caractères dans une chaine de caractères.

/* Notez que la méthode match() ne renvoie par défaut que la première correspondance 
trouvée. Pour que match() renvoie toutes les correspondances, il faudra utiliser l’option ou 
« drapeau » g qui permet d’effectuer des recherches globales. */

let str0 = "soit c'est du javascript,soit de l'HTML5 ou donc du CSS3"


//trouver 'de' dans la cjaine de caractères
document.getElementById('p1').innerHTML += str0.match(/de/) + '<br>';
//trouver le premier élément dans la liste des lettres majuscules entee A et Z
document.getElementById('p1').innerHTML += str0.match(/[A-Z]/) + '<br>';
//trouver tous les éléments dans l'intervalle des lettres majuscules
document.getElementById('p1').innerHTML += str0.match(/[A-Z]/g) + '<br>';
//trouver tous les chiffres entre 0 et 9
document.getElementById('p1').innerHTML += str0.match(/[0-9]/g);


//**La méthode search() de l’objet String**\\

//rôle?
/* La méthode search() permet d’effectuer une recherche dans une chaine de caractères à 
partir d’une expression régulière fournie en argument. */

//retourne?
/*Cette méthode va retourner la position à laquelle a été trouvée la première occurrence de l’expression recherchée dans une chaîne de caractères ou -1 si rien n’est trouvé.*/

//toutes les occurences du CSS
document.getElementById('p2').innerHTML +='CSS à la position : '+ str0.search(/CSS/g)+'<br>';

//un élément n'étant pas dans la chaine

document.getElementById('p2').innerHTML += 'python à la posotion'+str0.search(/python/g);

//**La méthode replace() de l’objet String**\\

//La méthode replace() permet de rechercher un caractère ou une séquence de caractères dans une chaine et de les remplacer par d’autres caractère ou séquence

//On va lui passer une expression régulière et une expression de remplacement en arguments

//retourne?
/* Cette méthode renvoie une nouvelle chaine de caractères avec les remplacements 
effectués mais n’affecte pas la chaine de caractères de départ qui reste inchangée. */

document.getElementById('p3').innerHTML += str0.replace(/javascript/g,'python');

//**La méthode split() de l’objet String**\\

//La méthode split() permet de diviser ou de casser une chaine de caractères en fonction d’un séparateur qu’on va lui fournir en argument.

//retourne?
/* Cette méthode va retourner un tableau de sous chaines créé à partir de la chaine de 
départ. La chaine de départ n’est pas modifiée. */

//espaces
document.getElementById('p4').innerHTML += str0.split(/ /) + '<br>';

//de
document.getElementById('p4').innerHTML += str0.split(/[0-5]/);

//**La méthode exec() de l’objet RegExp**\\

//La méthode exec() de RegExp va rechercher des correspondances entre une expression régulière et une chaine de caractères.

// retourne?
/* Cette méthode retourne un tableau avec les résultats si au moins une correspondance a 
été trouvée ou null dans le cas contraire. */

document.getElementById('p5').innerHTML += /javascript/g.exec(str0);

//**La méthode test() de l’objet RegExp**\\

//La méthode test() de RegExp va également rechercher des correspondances entre une expression régulière et une chaine de caractères

//mais va cette fois-ci renvoyer le booléen true si au moins une correspondance a été trouvée ou false dans le cas contraire.

if (/html/.test(str0.toLowerCase())){
  document.getElementById('p6').innerHTML += `HTML a été trouvé`;
} else{document.getElementById('p6').innerHTML += 'pas trouvé'}

//NB:::la chaine str0 n'est jamais affectée elle-même par ces changements





















