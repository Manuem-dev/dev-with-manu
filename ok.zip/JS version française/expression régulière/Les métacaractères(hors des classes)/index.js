/* Les métacaractères que 
nous étudions dans cette leçon ne vont avoir un sens spécial qu’en dehors des classes 
de caractères. */

/* il n’existe que trois métacaractères c’est-à-dire trois caractères qui vont 
posséder un sens spécial à l’intérieur des classes de caractères.  */

//**Le point**\\

let str = "Saluts. c'est moi 'je'. Encore un peu de dev python.contact +(085)698-45-347-6.ouuiiiiii"
let st = '2286404300'
//en dehors d’une classe de caractères, le point est un métacaractère qui permet de chercher n’importe quel caractère sauf une nouvelle ligne tandis que dans une classe de caractère le point sert simplement à rechercher le caractère point dans notre chaine de caractères

//NB:: chaque point représente alors le caractère qui vient avant ou après celui indiqué dans le masque selon la position du point
document.getElementById('p1').innerHTML += `${str.match(/u.../g)} <br>`;
document.getElementById('p1').innerHTML += `${str.match(/..u/g)} <br>`;
document.getElementById('p1').innerHTML += `${str.match(/[.]/g)} <br>`;

//**Les alternatives**\\

//se font avec '|'
//Concrètement, ce métacaractère va nous permettre de créer des masques qui vont pouvoir chercher une séquence de caractères ou une autre.

document.getElementById('p2').innerHTML += `${str.match(/u|j|i|e/g)} <br>`;
document.getElementById('p2').innerHTML += `${str.match(/python|javascript/g)} <br>`;


//**Les ancres**\\

//Les deux métacaractères ^ et $ vont nous permettre « d’ancrer » des masques
// '^' permet de chercher les caractères au début ou qui suivent une séquence
// '$' permet de chercher les caractères à la fin ou qui précèdent une séquence
//ils se placent soit en début(^) soit en fin($) de l'expression régulière ou de la classe

document.getElementById('p3').innerHTML += `${str.match(/.$/g)} <br>`; //un(1) caractère en fin de chaine
document.getElementById('p3').innerHTML += `${str.match(/^./g)} <br>`; //un(1) caractère en début de chaine
document.getElementById('p3').innerHTML += `${str.match(/..$/g)} <br>`; //deux(2) caractères en fin de chaine
document.getElementById('p3').innerHTML += `${str.match(/^...../g)} <br>`; //cinq(5) caractères en début de chaine
document.getElementById('p3').innerHTML += `${str.match(/^[A-Z]/g)} <br>`; // une lettre majuscule en début de chaine
 
//**Les quantificateurs**\\

//a{X} : On veut une séquence de X « a »
document.getElementById('p4').innerHTML += `${str.match(/i{2}/g)} <br>`;
//a{X,Y} : On veut une séquence de X à Y fois « a »
document.getElementById('p4').innerHTML += `${str.match(/i{2,4}/g)} <br>`;
//a{X,} : On veut une séquence d’au moins X fois « a » sans limite supérieure
document.getElementById('p4').innerHTML += `${str.match(/on{1,}/g)} <br>`;
document.getElementById('p4').innerHTML += `${str.match(/i{0,}/g)} <br>`;
//a? : On veut 0 ou 1 « a ». Équivalent à a{0,1}
document.getElementById('p4').innerHTML += `${str.match(/on?/g)} <br>`;
//a+ : On veut au moins un « a ». Équivalent à a{1,}
document.getElementById('p4').innerHTML += `${str.match(/i+/g)} <br>`;
//a* : On veut 0, 1 ou plusieurs « a ». Équivalent à a{0,}
document.getElementById('p4').innerHTML += `${str.match(/i*/g)} <br>`;

document.getElementById('p4').innerHTML += `${str.match(/^[A-Z].{5,40}/g)} <br>`;
document.getElementById('p4').innerHTML += `${str.match(/[a-z0-9].{5,36}$/g)} <br>`;//une séquence se terminant par un alohanumérique précédée d'au moins 5 caractères et d'au plus 36 caractères
document.getElementById('p4').innerHTML += `${str.match(/\([0-9].{5,}/g)} <br>`;//une séquence commençant par une ( suivi d'au moins 5 chiffres
document.getElementById('p4').innerHTML += `${st.match(/^\d{10,10}$/g)} <br>`;//si il y a exactement une séquence de 10 chiffres

