
let str = "c'est le Père qui l'aurait délivré donc!\nc'est super"

document.getElementById('p1').innerHTML += `${str.match(/père/)} <br>`; //cherche père
// 'i' placé à la fin du masque le rend insensible à la casse
document.getElementById('p1').innerHTML += `${str.match(/père/i)} <br>`;//cherche père Père pÈrE...

document.getElementById('p1').innerHTML += `${str.match(/s$/)} <br>`; //cherche 's' en fin de ligne

// 'm' permetde tenir compte des caractères de retour à la ligne et de retour chariot et faitque' ^ 'et '$' vont pouvoir être utilisés pour chercher un début et une fin de ligne
document.getElementById('p1').innerHTML += `${str.match(/^c/gm)} <br>`; // cherche 'c' en début de chaque ligne

// 's' avec '.' permet de chercher tous les caractères
document.getElementById('p1').innerHTML += `${str.match(/./s)} <br>`; //cherche le premier caractère de la chaine
document.getElementById('p1').innerHTML += `${str.match(/./gs)} <br>`; //cherche tous les caractères de la chaine 







