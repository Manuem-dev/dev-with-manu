//***Sous masques et assertions***\\

//**Les sous masques**\\

//Les métacaractères '(' et ')' vont être utilisés pour délimiter des sous masques.

//Un sous masque est une partie d’un masque de recherche. Les parenthèses vont nous permettre d’isoler des alternatives ou de définir sur quelle partie du masque un quantificateur doit s’appliquer.

let str = "Salut. on est toujours là nul anh! ok? okay bro!"

document.getElementById('p1').innerHTML += `${str.match(/ou|u/g)} <br>`; // cherche 'ou' ou 'u'

document.getElementById('p1').innerHTML += `${str.match(/o(u|n)/g)} <br>`; // cherche 'ou' ou 'on' et ne renvoie que ça car "g" a  été appliqué à la fin 

document.getElementById('p1').innerHTML += `${str.match(/o(u|n)/)} <br>`; // cherche 'ou' ou 'on' et  renvoie  aussi 'u' ou 'n'(les captures) car "g" n'a pas été appliqué à la fin
 
document.getElementById('p1').innerHTML += `${str.match(/tou(jour)s/g)} <br>`; // cherche la correspondance 'toujours' sans renvoyé de capture

document.getElementById('p1').innerHTML += `${str.match(/tou(jour)s/)} <br>`; // cherche la correspondance 'toujours' en renvoyant la capture 'jour'


//**Les assertions**\\

//Il existe à nouveau deux grands types d’assertions complexes :
//celles qui vont porter sur les caractères suivants celui à l’étude qu’on appellera également « assertion avant »
//celles qui vont porter sur les caractères précédents celui à l’étude qu’on appellera également « assertion arrière ».

//NB:: les assertions, à la différence des sous masques, ne sont pas capturantes par défaut et ne peuvent pas être répétées.


//a(?=b) : Cherche « a » suivi de « b » (assertion avant positive)(un certain nombre de 'a' sera renvoyé : celui ou ceux suivi de 'b')

document.getElementById('p2').innerHTML += `${str.match(/o(?=u)/g)} <br>`; // cherche la correspondance 'o' suivi de 'u'(un certain nombre de 'o' sera donc renvoyé:ceux suivi de 'u')

//a(?!b) : Cherche « a » non suivi de « b » (assertion avant négative)(un certain nombre de 'a' sera renvoyé : celui ou ceux n'étant pas suivi de 'b')

document.getElementById('p2').innerHTML += `${str.match(/o(?!u)/g)} <br>`; // cherche la correspondance 'o' n'étant pas suivi de 'u'(un certain nombre de 'o' sera donc renvoyé:ceux n'étant pas suivi de 'u')

//(?<=b)a : Cherche « a » précédé par « b » (assertion arrière positive)(un certain nombre de 'a' sera renvoyé : celui ou ceux précédé de 'b')

document.getElementById('p2').innerHTML += `${str.match(/(?<=o)u/g)} <br>`; // cherche la correspondance 'u' précédé de 'o'(un certain nombre de 'u' sera donc renvoyé:ceux précédé de 'o')

//(?<!b)a : Cherche « a » non précédé par « b » (assertion arrière négative)(un certain nombre de 'a' sera renvoyé : celui ou ceux non précédé de 'b')

document.getElementById('p2').innerHTML += `${str.match(/(?<!o)u/g)} <br>`; // cherche la correspondance 'u' n'étant pas précédé de 'o'(un certain nombre de 'u' sera donc renvoyé:ceux non  précédé de 'o')




