document.getElementById("p1").innerHTML = "enfin je réussi ce truc!!!";

//Opérateur ternaire et structure conditionnelle
function hide() {
  let pDisplay = document.getElementById("p4")
  pDisplay.style.display == 'block'? pDisplay.style.display = 'none': pDisplay.style.display = 'block'; //condition if?then:else;
}


//***Les Boucles***\\

//**Boucle while**\\
let x=0;
while (x<10){
  document.getElementById("p2").innerHTML += `x = ${x} <br>`
  x++;
}

let newg = document.getElementById("p3").innerHTML = '<a href="google.com">google</a>'

// **Boucle do...while** \\
let a = 15,b = 0;

//condition toujours vrai.
do{
    document.getElementById("p5").innerHTML += `b = ${b} <br>`;
  b++;
} while(b<10)
//condition non vérifiée mais s'exécute une fois
do {
    document.getElementById("p6").innerHTML += `a = ${a} <br>`;
  a++;
} while (a<10);

//**Boucle for**
for (let i=0;i<10;i++){
    document.getElementById("p7").innerHTML += `i = ${i} <br>`
};


//***Les Fonctions***\\

//**fonctions anonymes**\\

let anoFunc = function(){
  document.getElementById("p8").innerHTML = `ceci est une fonction
  anonyme`
};

anoFunc();

//**fonctions récursives**\\

/*Une fonction récursive est une fonction
qui va s’appeler elle-même au sein
de son code.*/

function recurs(t){
  if (t>0){
    document.getElementById('p9').innerHTML += `t = ${t} <br>`
    return recurs(t-1)
  } else{ return t }
};

recurs(15);



//****Programmation Orientée Objet(POO)****\\


//**Création d’un objet littéral**\\

/*Pour créer un objet littéral, on utilise une syntaxe utilisant une paire d’accolades { … } qui 
indique au JavaScript que nous créons un objet.*/

let obj = {
  nom: 'javascript',
  type: 'frontend',
  
  methode: function () {
   return `bonjour,ici c'est pour apprendre du ${this.nom} pour le developpement ${this.type}`
  }
};

/*Les membres d’un objet qui ne servent qu’à stocker des données sont appelés des 
propriétés tandis que ceux qui manipulent des données (c’est-à-dire ceux qui contiennent 
des fonctions en valeur) sont appelés des méthodes.*/

/*//*Utiliser le point pour accéder aux membres d’un objet, les 
modifier ou en définir de nouveaux*\\*/

/*Pour accéder aux propriétés et aux méthodes d’un objet, on utilise le caractère 
point . qu’on appelle également un accesseur. On va ici commencer par préciser le nom 
de l’objet puis l’accesseur puis enfin le membre auquel on souhaite accéder.
Cet accesseur va nous permettre non seulement d’accéder aux valeurs de nos différents 
membres mais également de modifier ces valeurs*/

//boucle for..in
for (let value in obj){
  document.getElementById('p').innerHTML += obj[value] + '<br>';
//  console.log(obj[value])
}

//accès aux valeurs des propriétés
document.getElementById("p10").innerHTML = `langage : ${obj.nom} <br>`;
document.getElementById("p10").innerHTML += `type : ${obj.type}`;

/*j'ai remarqué que le signe += permet de 
créer une nouvelle ligne ou une 
nouvelle balise avec cette 
syntaxe js en l'ajoutant dans le même
cadre.c'est un peu comme créer une 
nouvelle balise <p id='p10'></p>
donc avec les mêmes propriétés*/

//appel de la méthode 'methode' avant modification des valeurs des propriétés 
document.getElementById("p12").innerHTML = obj.methode() + "<br><br>";

//modification des valeurs des propriétés
obj.nom = 'python';
obj.type = 'backend';

document.getElementById("p11").innerHTML = `langage : ${obj.nom} <br>`;
document.getElementById("p11").innerHTML += `type : ${obj.type}`;

//appel des méthodes
//appel de la méthode 'methode' après modification des valeurs des propriétés 
document.getElementById("p12").innerHTML += obj.methode();


//***Définition et création d’un constructeur***\\

/*Un objet est un ensemble cohérent de propriétés et de méthodes.*/

//**La fonction construction d’objets : définition et création d’un constructeur**\\

/*Une fonction constructeur d’objets est une fonction qui va nous permettre de créer des 
objets semblables. En JavaScript, n’importe quelle fonction va pouvoir faire office de 
constructeur d’objets.*/

/*Pour construire des objets à partir d’une fonction constructeur, nous allons devoir suivre 
deux étapes : il va déjà falloir définir notre fonction constructeur et ensuite nous allons 
appeler ce constructeur avec une syntaxe un peu spéciale utilisant le mot clefs new.//appel de la méthode 'methode' avant modification des valeurs des propriétés 
*/

/*Dans une fonction constructeur, on va pouvoir définir un ensemble de propriétés et de 
méthodes. Les objets créés à partir de ce constructeur vont automatiquement posséder 
les (« hériter des ») propriétés et des méthodes définies dans le constructeur.
Comment une fonction peut-elle contenir des propriétés et des méthodes ? C’est très 
simple : les fonctions sont en fait un type particulier d’objets en JavaScript ! Comme tout 
autre objet, une fonction peut donc contenir des propriétés et des méthodes.*/

/*Notez que lorsqu’on définit un constructeur, on utilise par convention une majuscule au 
début du nom de la fonction afin de bien discerner nos constructeurs des fonctions 
classiques dans un script.*/

//**Créer des objets à partir d’une fonction constructeur**\\

function User(n,a,m,rD){
  //propriétés
  this.name = n;
  this.age = a;
  this.mail = m;
  this.registrationDate = rD;
  
  //méthode
  this.identity = function(){
    return `username: ${n};<br>
            age: ${a} years;<br>
            mail: ${this.mail};<br>
            member since: ${this.registrationDate}`
    /*on peut accéder aux valeurs des 
    propriétés soit directement avec leurs
    noms soit avec this.propriété*/
  }
}

/*En effet, l’idée d’un constructeur en JavaScript est de définir un plan de création d’objets. 
Comme ce plan va potentiellement nous servir à créer de nombreux objets par la suite, on 
ne peut pas initialiser les différentes propriétés en leur donnant des valeurs effectives, 
puisque les valeurs de ces propriétés vont dépendre des différents objets créés.*/

/*Le mot clef this est un mot clef qui apparait fréquemment dans les langages orientés 
objets. Dans le cas présent, il sert à faire référence à l’objet qui est couramment manipulé.
Pour le dire très simplement, c’est un prête nom qui va être remplacé par le nom de l’objet 
actuellement utilisé lorsqu’on souhaite accéder à des membres de cet objet.*/

/*utilité du mot clef this: 
Ce mot clef sert à représenter l’objet couramment utilisé. A chaque nouvel 
objet crée, il va être remplacé par l’objet en question et cela va nous permettre d’initialiser 
différemment chaque propriété pour chaque objet.*/

//*création d'un object*

/*Pour créer ensuite de manière effective des objets à partir de notre constructeur, nous 
allons simplement appeler le constructeur en utilisant le mot clef new. On dit également 
qu’on crée une nouvelle instance.*/

let yemo = new User("yemo",'21','yemodev@gmail.com','05 july 2025');

document.getElementById("p13").innerHTML += yemo.identity() + '<br>';
document.getElementById("p13").innerHTML += `nom d'utilisateur:  ${yemo.name}<br><br>`

/*Comme notre constructeur est une fonction, on va pouvoir l’appeler autant de fois qu’on 
le veut et donc créer autant d’objets que souhaité à partir de celui-ci et c’est d’ailleurs tout 
l’intérêt d’utiliser un constructeur. Chaque objet créé à partir de ce constructeur partagera 
les propriétés et méthodes de celui-ci.*/

//exemple
let stazy = new User("stazy",'34','stazyrypod@gmail.com','24 may 2019');
let kang = new User("kang",52,'kangdem@gmail.com','17 october 1997');
let samson = new User("samson",'63','samsamgo@gmail.com','07 february 2013');

document.getElementById("p13").innerHTML += stazy.identity() + '<br>';
document.getElementById("p13").innerHTML += `nom d'utilisateur:  ${stazy.name}<br><br>`
document.getElementById("p13").innerHTML += kang.identity() + '<br>';
document.getElementById("p13").innerHTML += `nom d'utilisateur:  ${kang.name}<br><br>`
document.getElementById("p13").innerHTML += samson.identity() + '<br>';
document.getElementById("p13").innerHTML += `nom d'utilisateur:  ${samson.name}<br>`

//**Constructeur et différenciation des objets**\\

/*La fonction constructeur doit vraiment être vue en JavaScript comme un plan de base pour 
la création d’objets similaires et comme un moyen de gagner du temps et de la clarté dans 
son code. On ne va définir dans cette fonction que les caractéristiques communes de nos 
objets et on pourra ensuite rajouter à la main les propriétés particulières à un objet.*/

//ajout d'une propriété spécifique à un objet donné
stazy.poids = 53;
document.getElementById(`p14`).innerHTML += stazy.identity() + '<br>';
document.getElementById(`p14`).innerHTML += 'poids: '+ stazy.poids + 'kg';
document.getElementById(`p14`).innerHTML += `<br> nom d'utilisateur:  ${stazy.name}<br><br>`


//NB::::::::::
/*je vais définir une fonction qui va prendre
en paramètre le numéro de l'id d'une balise
p après le p(p14 par exemple) pour simplifier
les document.get...ID('p14').innerHtml.
elle va s'appeler htlml()*/
function htmlDocIdGet(id){
  return document.getElementById(id)
}

//***Constructeur Object, prototype et héritage***\\

//**Le prototype en JavaScript orienté objet**\\

/*Dans les langages orientés objet utilisant des prototypes comme le JavaScript, tout est 
objet et il n’existe pas de classes et l’héritage va se faire au moyen de prototypes*/

/*les fonctions en JavaScript sont avant tout des 
objets. Lorsqu’on créé une fonction, le JavaScript va automatiquement lui ajouter une 
propriété prototype qui ne va être utile que lorsque la fonction est utilisée comme 
constructeur, c’est-à-dire lorsqu’on l’utilise avec la syntaxe new.
Cette propriété prototype possède une valeur qui est elle-même un objet. On parlera donc 
de « prototype objet » ou « d’objet prototype » pour parler de la propriété prototype.*/

/*Par défaut, la propriété prototype d’un constructeur ne contient que deux propriétés : une 
propriété constructor qui renvoie vers le constructeur contenant le prototype et une 
propriété __proto__ qui contient elle-même de nombreuses propriétés et méthodes.*/

/*Lorsqu’on crée un objet à partir d’un constructeur, le JavaScript va également ajouter 
automatiquement une propriété __proto__ à l’objet créé.
La propriété __proto__ de l’objet créé va être égale à la propriété __proto__ du constructeur 
qui a servi à créer l’objet.*/

//pratique
/*on avait eu à dire que la propriété poids
était spécifique pour un seul objet sur
lequel elle a été ajoutée*/

/*En fait, le contenu de la propriété prototype d’un constructeur va être partagé par tous les 
objets créés à partir de ce constructeur. Comme cette propriété est un objet, on va pouvoir 
lui ajouter des propriétés et des méthodes que tous les objets créés à partir du 
constructeur vont partager.
Cela permet l’héritage en orienté objet JavaScript. On dit qu’un objet « hérite » des 
membres d’un autre objet lorsqu’il peut accéder à ces membres définis dans l’autre objet.*/

/*Pour faire fonctionner cela en pratique, il faut se rappeler que la propriété prototype est 
un objet et qu’on va donc pouvoir lui ajouter des propriétés et des méthodes comme pour 
tout autre objet*/

//exemple
User.prototype.number = ' 90 90 50 40';
User.prototype.hi = function(){
  return `hello ${this.name}.<br> glad that we can call you on ${this.number}`
}
/*Ici, on ajoute une propriété number et une méthode hi() à la propriété prototype du 
constructeur User(). Chaque objet créé à partir de ce constructeur va avoir accès à 
cette propriété et à cette méthode.*/

//testons avec de nouveaux objets

let def = new User('david',23,'dev@yahoo.fr','06 march 2024');
let dev = new User('john',43,'johv@yahoo.fr','12 april 2004');

htmlDocIdGet('p15').innerHTML += '<br>' + def.identity() + '<br>';
htmlDocIdGet('p15').innerHTML += `numéro: (+001)${dev.number} <br>`;
htmlDocIdGet('p15').innerHTML += '<br>' + dev.identity() + '<br>';
htmlDocIdGet('p15').innerHTML += `numéro: (+001)${dev.number} <br>`;
htmlDocIdGet('p15').innerHTML += '<br>'+ def.hi()+'<br>';
htmlDocIdGet('p15').innerHTML += '<br>'+ dev.hi();

/*Définir des propriétés et des méthodes dans le prototype d’un constructeur nous permet 
ainsi de les rendre accessible à tous les objets créés à partir de ce constructeur sans que 
ces objets aient à les redéfinir.*/

/*Pour avoir le code le plus clair et le plus performant possible, nous définirons donc 
généralement les propriétés des objets (dont les valeurs doivent être spécifiques à l’objet) 
au sein du constructeur et les méthodes (que tous les objets vont pouvoir appeler de la 
même façon) dans le prototype du constructeur.*/


//**Mise en place d’une hiérarchie d’objets avec héritage en JavaScript**\\

/*Quel intérêt à faire cela ? Parfois, nous voudrons créer des types d’objets relativement 
proches. Plutôt que de redéfinir un constructeur entièrement à chaque fois, il va être plus 
judicieux de créer un constructeur de base qui va contenir les propriétés et méthodes 
communes à tous nos objets puis des constructeurs plus spécialisés qui vont hériter de 
ce premier constructeur.*/

/*Pour mettre en place un héritage ou plus exactement un système de délégation (qui est 
un mot beaucoup plus juste que le terme « héritage » dans le cas du JavaScript), nous 
allons toujours procéder en trois étapes :
1. On va déjà créer un constructeur qui sera notre constructeur parent ;
2. On va ensuite un constructeur enfant qui va appeler le parent ;
3. On va modifier la __proto__ de la propriété prototype de l’enfant pour qu’elle soit 
égale au parent.*/

/*Pour information, la méthode call() permet d’appeler une fonction rattachée à un objet 
donné sur un autre objet. La méthode call() est une méthode prédéfinie qui appartient au 
prototype de l’objet natif Function.*/

//ça risque d'être dur

function Ligne(longueur){
  this.longueur = longueur;
}

Ligne.prototype.distance = function (){
  return document.getElementById("p16").innerHTML = `distance: ${this.longueur} m <br>`;
};

function Rectangle(longueur,largeur){
  Ligne.call(this,longueur);
  /*On l’utilise ici pour faire appel au constructeur Ligne() dans notre constructeur Rectangle(). 
Le mot clef this permet de faire référence à l’objet courant et de passer la valeur de l’objet 
relative à sa propriété longueur.*/
  this.largeur = largeur;
}
/*Pour information, la méthode call() permet d’appeler une fonction rattachée à un objet 
donné sur un autre objet. La méthode call() est une méthode prédéfinie qui appartient au 
prototype de l’objet natif Function.*/
Rectangle.prototype = Object.create(Ligne.prototype);
/*il va nous falloir rétablir la valeur de la 
propriété constructor de prototype de Rectangle car la ligne précédente a eu pour effet de 
définir Rectangle.prototype.constructor comme étant égal à celui de Ligne().*/
Rectangle.prototype.constructor = Rectangle;
Rectangle.prototype.aire = function (){
  return htmlDocIdGet('p16').innerHTML += `Aire: ${this.longueur*this.largeur} m² <br>`;
};

/*On répète l’opération en création un deuxième niveau d’héritage avec le 
constructeur Parallélépipède() qui va hériter de Rectangle().*/
function parallelepipede(longueur,largeur,hauteur){
  Rectangle.call(this,longueur,largeur);
  this.hauteur = hauteur;
}

parallelepipede.prototype = Object.create(Rectangle.prototype);
parallelepipede.prototype.constructor = parallelepipede;
parallelepipede.prototype.volume = function(){
  return htmlDocIdGet("p16").innerHTML += `volume: ${this.longueur*this.largeur*this.hauteur} m³`;
}

/*Enfin, on crée un objet geo à partir du constructeur Parallélépipède(). Cet objet va pouvoir 
utiliser les méthodes définies dans les prototypes de Parallélépipède(), de Rectangle() et 
de Ligne() !*/
let geo = new parallelepipede(10,5,3);
geo.distance();
geo.aire();
geo.volume();

//***Les classes en orienté objet JavaScript***\\

/*Une classe est un plan général qui va servir à créer des objets similaires. Le code d’une 
classe va généralement être composé de propriétés et de méthodes dont vont hériter les 
objets qui vont être créés à partir de la classe.*/

/*Une classe va également contenir une méthode constructeur qui va être appelée
automatiquement dès qu’ on va créer un objet à partir de notre classe et va nous permettre
d’ initialiser les propriétés d’ un objet.*/

/*Il existe de grandes différences conceptuelles entre les langages orientés objet basés sur 
les classes et ceux bases sur les prototypes. On peut notamment noter les suivantes :
• Dans les langages basés sur les classes, tous les objets sont créés en instanciant 
des classes ;
• Une classe contient toutes les définitions des propriétés et méthodes dont dispose 
un objet. On ne peut pas ensuite rajouter ou supprimer des membres à un objet 
dans les langages basés sur les classes ;
• Dans les langages basés sur les classes, l’héritage se fait en définissant des 
classes mères et des classes étendues ou classes enfants.*/

//**Création d’une classe et d’objets en JavaScript**\\

//NB:: 
/*Nous n'avons pas besoin de préciser
'function' devant notre constructeru et devant
nos méthodes*/

class Cube{
  constructor(longueur,largeur,hauteur){
    this.longueur = longueur;
    this.largeur = largeur;
    this.hauteur = hauteur;
  }
  
  volume(){
     htmlDocIdGet('p17').innerHTML += ` volume : ${this.longueur*this.largeur*this.hauteur} m³`
  }
}
//création d'un objet avec la classe Cube
let cal = new Cube(10,5,3)
cal.volume()

//**Classes étendues et héritage en JavaScript**\\

/*Pour étendre une classe, c’est-à-dire pour créer une classe enfant qui va hériter des 
propriétés et des méthodes d’une classe parent, nous allons utiliser le mot clef extends*/

//exemple de class enfant
class Rectangles extends Cube{
  /*La chose à savoir ici est que nous devons utiliser le mot clef super() qui permet d’appeler 
le constructeur parent dans le constructor() de notre classe fille afin que les propriétés 
soient correctement initialisées.*/
  constructor(longueur,largeur){
    super(longueur,largeur); //appel des propriétés parents
  /*si rectangle avait plus de propriétés
  que la classe parent Cube,alors les 
  propriétés de surplus sont aussi
  instanciées avec this.propriété après le
  super(propriétéParent1,propriétéParent2,..,propriétéParentn)*/
  }
  
  aire(){
    htmlDocIdGet('p18').innerHTML += `Aire: ${this.longueur*this.largeur} m²`
  }
}

//création d'un objet héritier
let test = new Rectangles(20,35);
test.aire();


//****VALEURS PRIMITIVES ET OBJETS GLOBAUX****\\

//***Valeurs primitives et objets prédéfinis***\\

/*Vous devez savoir que le JavaScript dispose également de constructeurs d’objets 
prédéfinis dans son langage. Ces constructeurs vont disposer de propriétés et de 
méthodes intéressantes qu’on va pouvoir immédiatement utiliser avec les objets qu’on va 
créer à partir de ces constructeurs*/

//**Définition des valeurs primitives et différence avec les objets**\\

/*On appelle valeur primitive en JavaScript une valeur qui n’est pas un objet et qui ne peut 
pas être modifiée.*/

//***Propriétés et méthodes de l’objet global String***\\

//**Les propriétés de l’objet String**\\

/*Le constructeur String() ne possède que deux propriétés : une propriété length et, bien 
évidemment, une propriété prototype comme tout objet.*/

htmlDocIdGet('p19').innerHTML += "du string uniquement".length

//**Les méthodes de l’objet String**\\
/*Elles sont habituellemnent sensibles à la casse*/
//*La méthode includes()*\\

/*La méthode includes() permet de déterminer si une chaine de caractères est incluse dans 
une autre. Cette méthode prend l’expression (la chaine) à rechercher en argument.*/

//exemple
/*supposons qu'on veut uniquement des adresses
mail de gmail*/
let str0 = 'exemple@gmail.com';
let str1 = 'gmail.com';

htmlDocIdGet('p20').innerHTML += `str1 est incluse dans str0? ${str0.includes(str1)} <br>`
if (str0.includes(str1)){
  htmlDocIdGet('p20').innerHTML += 'votre mail est valide'
} else{
  null;
}

//*Les méthodes startsWith() et endsWith()*\\

/*La méthode startsWith() permet de déterminer si une chaine commence par une certaine 
sous chaine (ou expression). Si c’est le cas, cette méthode renvoie true. Dans le cas 
contraire, c’est le booléen false qui est renvoyé.*/
/*La méthode endsWith() permet de déterminer si une chaine se termine par une certaine 
sous chaine. */
let str2 = 'javascript est le best web language';

if (str2.startsWith('python') || str2.startsWith('javascript')){
  htmlDocIdGet('p21').innerHTML += `la chaine : '${str2}' débute avec *javascript* <br>`;
} 
if (str2.endsWith('language')){
  htmlDocIdGet('p21').innerHTML += `la chaine : '${str2}' se termine avec *language*`;
}

//*La méthode substring()*\\

/*Cette méthode demande un indice de départ en argument obligatoire qui va servir à 
indiquer la position de départ de la sous-chaine. On va également pouvoir passer un 
deuxième indice facultatif pour préciser une position de fin pour notre sous-chaine.*/
let str3 = 'ici c\'est javascript pour le web';
let str4 = str3.substring(10)
htmlDocIdGet('p22').innerHTML += str4 + '<br>';

let str5 = str3.substring(4,20)
htmlDocIdGet('p22').innerHTML += str5;


//*Les méthodes indexOf() et lastIndexOf()*\\

/*La méthode indexOf() permet de déterminer la position de la première occurrence d’un 
caractères ou d’une chaine de caractères dans une chaîne de caractères de base.
Cette méthode va prendre l’expression à rechercher dans la chaine de caractères en 
argument et va renvoyer la position à laquelle cette expression a été trouvée la première 
fois dans la chaine si elle est trouvée ou la valeur -1 si l’expression n’a pas été trouvée 
dans la chaine.*/

/*La méthode lastIndexOf() va fonctionner exactement de la même manière que sa 
sœur indexOf() à la différence près que c’est la position de la dernière occurrence de 
l’expression cherchée qui va être renvoyée (ou -1 si l’expression n’est pas trouvée dans 
la chaine).*/

let str6 = 'c\'est genial ça!!!'
htmlDocIdGet("p23").innerHTML += str6.indexOf('i');
htmlDocIdGet('p23').innerHTML += str6.lastIndexOf('e');

//*La méthode slice()*\\

/* La méthode slice() extrait une section d’une chaine de caractères et la retourne comme 
une nouvelle chaine de caractères. La chaîne de caractères de départ n’est pas modifiée */

/* On doit fournir en argument de départ obligatoire la position de départ dans la chaine de 
caractères de départ où doit démarrer l’extraction. On peut également passer en deuxième 
argument optionnel la positon où l’extraction doit s’arrêter */

/* Cette méthode va donc fonctionner comme substring() à deux différences près :
• En passant des valeurs négatives en argument à slice(), les positions de départ et 
de fin d’extraction seront calculées à partir de la fin de la chaine de caractères à 
partir de laquelle on extrait ;
• En passant une position de départ plus lointaine que la position d’arrivée à slice(), 
cette méthode n’inverse pas les valeurs mais renvoie une chaine de caractères 
vide.

Vous pouvez également noter que la méthode slice() ne modifie pas la chaine de 
caractères d’origine mais renvoie une nouvelle chaine */

let str7 = 'essayons donc cette méthode';
htmlDocIdGet("p24").innerHTML += str7.slice(str7.lastIndexOf('s')+1)+'<br>';
htmlDocIdGet('p24').innerHTML += str7.slice(0,str7.indexOf('donc')-1)+'<br>';
htmlDocIdGet('p24').innerHTML += str7.slice(-(str7.lastIndexOf('méthode')-1),-(str7.lastIndexOf('cette'))+1);


//*La méthode replace()*\\

/*La méthode replace() nous permet de rechercher une expression dans une chaine de 
caractères et de la remplacer par une autre.*/

/*dans le cas où on passe une expression de type chaine de caractères à 
rechercher, seule la première occurrence dans la chaine sera remplacée. Pour pouvoir 
remplacer toutes les occurrences, il faudra passer une expression régulière comme 
schéma de recherche à cette méthode*/

let str8 = 'javascript est le best des langages';
htmlDocIdGet('p25').innerHTML += str8.replace('javascript','python');

//*Les méthodes toLowerCase() et toUpperCase()*\\

/*La méthode toLowerCase() retourne une chaine de caractères en minuscules.
A l’inverse, la méthode toUpperCase() retourne une chaine de caractères en majuscules.*/

let str9 = 'FrontEnd';

htmlDocIdGet('p26').innerHTML += str9.toLowerCase() + '<br>';
htmlDocIdGet('p26').innerHTML += str9.toUpperCase();


//*La méthode trim()*\\

/* La méthode trim() supprime les espaces ou les « blancs » en début et en fin de chaîne. 
Cette méthode va s’avérer très pratique lorsqu’on voudra nettoyer des données pour 
ensuite effectuer des opérations dessus. */

let str10 = '    c\'est donc du python     ';

htmlDocIdGet('p27').innerHTML += str10.trim()


//***Propriétés et méthodes de l’objet global Number***\

//**Les propriétés de l’objet Number**\\

/* La plupart des propriétés de l’objet Number sont des propriétés dites statiques. Cela 
signifie qu’on ne va pouvoir les utiliser qu’avec l’objet Number en soi et non pas avec une 
instance de Number() (ni donc avec une valeur primitive). */

/* Les propriétés à connaitre sont les suivantes :
• Les propriétés MIN_VALUE et MAX_VALUE représentent respectivement les plus 
petite valeur numérique positive et plus grand valeur numérique qu’il est possible 
de représenter en JavaScript ;
• Les propriétés MIN_SAFE_INTEGER et MAX_SAFE_INTEGER représentent 
respectivement le plus petit et le plus grand entiers représentables correctement 
ou de façon « sûre » en JavaScript. L’aspect « sûr » ici faire référence à la capacité 
du JavaScript à représenter exactement ces entiers et à les comparer entre eux. 
Au-delà de ces limites, les entiers différents seront jugés égaux ;
• Les propriétés NEGATIVE_INFINITY et POSITIVE_INFINITY servent respectivement 
à représenter l’infini côté négatif et côté positif ;
• La propriété NaN représente une valeur qui n’est pas un nombre (« NaN » est 
l’abréviation de « Not a Number ») et est équivalente à la valeur NaN. */

//**Les méthodes de l’objet Number**\\

//*La méthode isFinite()*\\

/* La méthode isFinite() permet de déterminer si une valeur fournie est un nombre fini. On 
va lui passer en argument la valeur à tester.
Si l’argument passé est bien une valeur finie, isFinite() renverra le booléen true. Dans le 
cas contraire, cette méthode renverra la booléen false. */

//*La méthode isInteger()*\\

/* La méthode isInteger() permet de déterminer si une valeur est un entier valide.
Si la valeur testée est bien un entier, la méthode isInteger() renverra le booléen true. Dans 
le cas contraire, cette méthode renverra la booléen false.
Notez que si la valeur testée est NaN ou l’infini, la méthode renverra également false. */

//*La méthode isNaN()*\\

/* La méthode isNaN() permet de déterminer si la valeur passée en argument est la 
valeur NaN (valeur qui appartient au type Number).
On va lui passer en argument la valeur qui doit être comparée à NaN. Si la valeur passée 
est bien égale à NaN, notre méthode renverra le booléen true. Dans le cas contraire, le 
booléen false sera renvoyé. */

//*La méthode isSafeInteger()*\\

/* La méthode isSafeInteger() permet de déterminer si une valeur est un entier sûr (un entier 
que le JavaScript peut représenter correctement).
Cette méthode prend la valeur à tester en argument et retourne le booléen true si la valeur 
est bien un entier sûr ou false sinon. */

//*La méthode parseFloat()*\\

/* La méthode parseFloat() permet de convertir une chaîne de caractères en un nombre 
décimal. Pour cela, on va lui passer la chaine à transformer en argument et la méthode 
renverra un nombre décimal en retour. */

/* L’analyse de la chaîne s’arrête dès qu’un caractère qui n’est pas +,-, un chiffre, un point 
ou un exposant est rencontré. Ce caractère et tous les suivants vont alors être ignorés. Si 
le premier caractère de la chaîne ne peut pas être converti en un 
nombre, parseFloat() renverra la valeur NaN. */

//*La méthode parseInt()*\\

/* La méthode parseInt() permet de convertir une chaine de caractères en un entier selon 
une base et va renvoyer ce nombre en base 10. On va lui passer deux arguments : la 
chaine de caractères à convertir et la base utilisée pour la conversion. */

/* En programmation web, on utilise également aussi parfois des bases octales (base 8) qui 
utilisent 8 unités ainsi que des bases hexadécimales (base 16), notamment pour définir 
les couleurs en CSS. */

/* Une base hexadécimale utilise 16 unités. Pour représenter le « 10 » de notre base 10 en 
hexadécimale, on utilise le chiffre 0 suivi de la lettre A. Le 11 est représenté par 0B, le 12 
par 0C, le 13 par 0D, le 14 par 0E et le 15 par 0F. */

//*La méthode toFixed()*\\

/* La méthode toFixed() permet de formater un nombre en indiquant le nombre de décimales 
(nombre de chiffres après la virgule) qu’on souhaite conserver. */

/* On va indiquer en argument de cette méthode le nombre de décimales souhaitées et notre 
méthode va renvoyer une chaine de caractères qui représente le nombre avec le nombre 
de décimales souhaitées. */

/* Dans le cas où on demande à toFixed() de renvoyer un nombre avec moins de décimales 
que le nombre de base, l’arrondi se fera à la décimale supérieure si la décimale suivant 
celle où le nombre doit être arrondi est 5 ou supérieure à 5. */

//*La méthode toPrecision()*\\

/* La méthode toPrecision() est relativement similaire à la méthode toFixed(). Cette méthode 
permet de représenter un nombre avec un nombre de chiffre données (avec une certaine 
« précision »). */

/* On va lui passer en argument le nombre de chiffres qu’on souhaite conserver et celle-ci 
va renvoyer une chaine de caractères représentant notre nombre avec le bon nombre de 
chiffres. */

/* Les règles d’arrondi vont être les mêmes
que pour la méthode toFixed(). */

//*La méthode toString()*\\

/* La méthode toString() permet de transformer un nombre en une chaine de caractères. On 
va pouvoir lui passer une base en argument pour formater notre nombre. Elle renverra 
une chaine de caractères représentant notre nombre. */



//***Propriétés et méthodes de l’objet global Math***\\\


//**Les propriétés de l’objet Math**\\

/* Les propriétés de l’objet Math stockent des constantes mathématiques utiles.
• Math.E a pour valeur le nombre d’Euler (base des logarithmes naturels ou encore 
exponentiel de 1), soit environ 2,718 ;
• Math.LN2 a pour valeur le logarithme naturel de 2, soit environ 0,693 ;
• Math.LN10 a pour valeur le logarithme naturel de 10, soit environ 2,302 ;
• Math.LOG2E a pour valeur le logarithme naturel de 2, soit environ 0,693;
• Math.LOG10E a pour valeur le logarithme naturel de 10, soit environ 2,302 ;
• Math.pi a pour valeur pi, soit environ 3,14159 ;
• Math.SQRT1_2 a pour valeur la racine carrée de ½, soit environ 0,707 ;
• Math.SQRT2 a pour valeur la racine carrée de 2, soit environ 1,414. */

//**Les méthodes de l’objet Math**\\

//*Les méthodes floor(), ceil(), round() et trunc()*\\

/* Les méthodes floor(), ceil(), round() et trunc() permettent toutes les quatre d’arrondir ou 
de tronquer un nombre décimal afin de le transformer en entier. */

/* La méthode floor() va arrondir la valeur passée en argument à l’entier immédiatement 
inférieur (ou égal) à cette valeur. */

/* La méthode ceil(), au contraire, va arrondir la valeur passée en argument à l’entier 
immédiatement supérieur (ou égal) à cette valeur. */

/* La méthode round() va elle arrondi la valeur passée en argument à l’entier le plus proche. 
Ainsi, si la partie décimale de la valeur passée est supérieure à 0,5, la valeur sera arrondie 
à l’entier supérieur. Dans le cas contraire, la valeur sera arrondie à l’entier inférieur. Dans 
le cas où la partie décimale vaut exactement 0,5, la valeur sera arrondie à l’entier supérieur 
(dans la direction de l’infini positif). */

/* Finalement, la méthode trunc() va tout simplement ignorer la partie décimale d’un nombre 
et ne retourner que sa partie entière */

//*La méthode random()*\\

/* La méthode random() permet de générer un nombre décimal compris entre 0 (inclus) et 1 
(exclu) de manière pseudo-aléatoire. */

/* On va ensuite pouvoir multiplier son résultat par un autre nombre afin d’obtenir un nombre 
pseudo-aléatoire compris dans l’intervalle de notre choix. */

//*Les méthodes min() et max()*\\

/* La méthode min() renvoie le plus petit nombre d’une série de nombres passés en 
arguments. La méthode max(), au contraire, va renvoyer le plus grand nombre d’une série 
de nombres passés en arguments. */

/* Dans les deux cas, si l’une des valeurs fournies en argument n’est pas un nombre et ne 
peut pas être convertie en nombre, alors ces méthodes renverront la valeur NaN */

//*La méthode abs()*\\

/* La méthode abs() renvoie la valeur absolue d’un nombre, c’est-à-dire le nombre en 
question sans signe. */

/* Si la valeur fournie en argument n’est pas un nombre et ne peut pas être convertie en 
nombre, alors elle renverra NaN. */

//*Les méthodes cos(), sin(), tan(), acos(), asin() et atan()*\\

/* Les méthodes cos(), sin(), tan(), acos(), asin() et atan() retournent respectivement le 
cosinus, le sinus, la tangente, l’arc cosinus, l’arc sinus et l’arc tangente d’une valeur 
passée en argument. */

/* Les valeurs passées et retournées sont exprimées en radians. Pour convertir une valeur 
en radians en une valeur en degrés, il suffit de multiplier la valeur en radians par 180 et 
de diviser par pi (180° = pi radian, 360° = 2pi radian). */

//*Les méthodes exp() et log()*\\

/* Les méthodes exp() et log() renvoient respectivement l’exponentielle et le logarithme 
népérien (ou logarithme naturel) d’une valeur passée en argument. */

//***Présentation des tableaux et de l’objet global Array***\\

//*Création d’un tableau en JavaScript*\\

/* Cette syntaxe utilise les crochets […] */

//*Accéder à une valeur dans un tableau*\\

/* Pour accéder à une valeur en particulier dans un tableau, il suffit de préciser le nom du 
tableau puis l’indice associé à la valeur à laquelle on souhaite accéder entre crochets. */

/* Dans le cas où un tableau stocke un autre tableau, il faudra utiliser deux paires de crochets 
: la première paire va mentionner l’indice relatif à la valeur à laquelle on souhaite accéder 
dans notre tableau de base (c’est-à-dire l’indice lié au sous tableau en l’occurrence, tandis 
que la deuxième parie de crochets va nous permettre de préciser l’indice lié à la valeur à 
laquelle on souhaite accéder dans notre sous tableau. */

//**Utiliser une boucle for…of pour parcourir toutes les valeurs d’un tableau**\\

let elements = ['python','javascript',['flask','django','fastApi'],['vanilla','vue','svelte']];

//For of loop
for (let element of elements){
  htmlDocIdGet('p28').innerHTML += element + '<br>';
  //console.log(element);
  /* Ici, on définit une variable (on peut lui donner le nom qu’on souhaite) qui va 
  stocker les différentes valeurs de notre tableau une à une. La boucle for… of va en effet 
  exécuter son code en boucle jusqu’à ce qu’elle arrive à la fin du tableau */
}

//**Tableaux associatifs en JavaScript, objets littéraux et boucle for… in**\\

/* on va pouvoir utiliser une boucle for… in pour parcourir les propriétés 
d’un objet littéral une à une. La boucle for…in est l’équivalent de la boucle for…of mais 
pour les objets. */

let user = {
  name:'king',
  mail:'kingstar@gmail.com',
  languages: ['python','javascript']
}

//For..in loop
for (let prop in user){
  htmlDocIdGet('p29').innerHTML += user[prop] + '<br>';

  /* on accède ici aux valeurs avec
  objet[propriété] si on a un 
  for (let propriété in objet) puisque
  c'est ainsi que s'exécute le code*/
}


//***les méthodes du constructeur Array()***\\

//NB: 
/*les deux propriétés que possède Array() sont:
length et prototype*/

//*Les méthodes push() et pop()*\\

/* La méthode push() va nous permettre d’ajouter des éléments en fin de tableau et va 
retourner la nouvelle taille du tableau. */
//push()
let arr0 = ['python','javascript'];
let arr0_ = arr0.push("C++",'C#'); //retourne arr0.length(taile du nouveau tableau)
//arr0 est automatiquement modifié
htmlDocIdGet('p30').innerHTML += `on a donc [${arr0}] à ${arr0_} éléments <br><br>`;

/*La méthode pop() va elle nous permettre de supprimer le dernier élément d’un tableau et 
va retourner l’élément supprimé.*/
//pop()
let arr1 = arr0.pop(); //ne prend pas d'argument                                   
//renvoi donc l'élément supprimé
htmlDocIdGet('p30').innerHTML += `le nouveau tableau [${arr0}] avait connu la suppression de l'élément ${arr1}`
                                  

//*Les méthodes unshift() et shift()*\\

/* Ces deux méthodes sont donc les équivalentes des méthodes push() et pop() à la 
différence que les éléments vont être ajoutés ou supprimés en début de tableau et non 
pas en fin */

/* La méthode unshift() va nous permettre d’ajouter des éléments en début de tableau et va 
retourner la nouvelle taille du tableau. Nous allons passer les éléments à ajouter en 
argument */
//unshift()
let arr2 = ['java','ruby'];
let arr2_ = arr2.unshift('c++','python','javascript'); //retourne la taille de arr2(arr2.length)
htmlDocIdGet('p31').innerHTML += `le tableau [${arr2}] contient ${arr2_} éléments<br>`

/* La méthode shift() va elle nous permettre de supprimer le premier élément d’un tableau 
et va retourner l’élément supprimé. */
//shift()
let arr3 = arr2.shift(); //retourne l'élément supprimé
htmlDocIdGet('p31').innerHTML += `<br>le tableau [${arr2}] est obtenu suite à la suppression de ${arr3}`


//*La méthode splice()*\\

/* Pour ajouter, supprimer ou remplacer des éléments dans un tableau, on peut également 
utiliser splice(). */

/* La méthode splice() va pouvoir prendre trois arguments : une position de départ à partir 
d’où commencer le changement, le nombre d’éléments à remplacer et finalement les 
éléments à ajouter au tableau. */

/* Si on précise 0 en nombre d’éléments à remplacer, alors aucun élément ne sera supprimé 
du tableau de base. Dans ce cas, il sera nécessaire de préciser des éléments à rajouter */

/* Enfin, si on ne précise pas d’éléments à rajouter au tableau, le nombre d’éléments à 
remplacer tel quel précisé en deuxième argument seront supprimés du tableau à partir de 
la position indiquée en premier argument. */

//NB
/* Cette méthode va également retourner 
un tableau contenant les éléments supprimés. */

/* en indiquand la position de départ,
les éléments rajoutés prendront place
juste(prendront donc la place de l'indice désigné) après l'élément indice-1 de l'indice de
position de départ(exemple de 2,alors 
l'ajout commence aorès l'élélent d'indice 1 et 
avant l'élément d'indice 2*/

let arr4 = ['java','javascript'];
let arr4_ = arr4.splice(1,0,'python','ruby','go','c');

htmlDocIdGet('p32').innerHTML += `[${arr4}] <br><br>`

/* En cas de suppression,la
suppression commence à partir de l'indice
de la position de départ désignée*/

let arr5 = arr4.splice(3,3);
htmlDocIdGet('p32').innerHTML += '[' + arr5 + ']' + ' ont été supprimé et il reste ' + '[' + arr4 + ']';

//*La méthode join()*\\

/* La méthode join() retourne une chaine de caractères créée en concaténant les différentes 
valeurs d’un tableau. Le séparateur utilisé par défaut sera la virgule mais nous allons 
également pouvoir passer le séparateur de notre choix en argument de join(). */

arr4 = arr4.join('|')
htmlDocIdGet('p33').innerHTML += arr4;

//*La méthode slice()*\\

/* La méthode slice() renvoie un tableau
créé en découpant un tableau de départ. */

/* Cette méthode va prendre en premier argument facultatif la position de départ où doit 
commencer la découpe de notre tableau de départ. Si la position passée est un nombre 
négatif, alors le début de la découpe sera calculé à partir de la fin du tableau de départ. Si 
aucune position de départ n’est passée, la découpe commencera depuis le début du 
tableau de départ. */

/* On va également pouvoir lui passer en second argument facultatif la position où doit 
s’arrêter la découpe du tableau de départ. Si la position passée est un nombre négatif, 
alors la fin de la découpe sera calculé à partir de la fin du tableau de départ. Si aucune 
position de fin n’est passée, alors on récupèrera le tableau de départ jusqu’à la fin pour 
créer notre nouveau tableau. */

let arr6 = ['python','go','java','javascript','ruby','r','c','c++','c#']
let arr6_ = arr6.slice(1,5); //dernier indice exclus(5 = 'r')
htmlDocIdGet('p34').innerHTML +='['+ arr6_+']';

//*La méthode concat()*\\

/* La méthode concat() va nous permettre de fusionner différents tableaux entre eux pour en 
créer un nouveau qu’elle va renvoyer. */

/* Cette méthode va prendre en arguments les tableaux que l’on souhaite concaténer à un 
premier de départ qu’on va pouvoir choisir arbitrairement. */

let arr7 = [].concat(arr6,arr1,arr3);
let arr8 = arr7.join(' & ');
htmlDocIdGet('p35').innerHTML+=arr8;

//*La méthode includes()*\\

/* La méthode includes() permet de déterminer si un tableau contient une valeur qu’on va 
passer en argument. Si c’est le cas, includes() renvoie true. Dans le cas contraire, cette 
méthode renvoie false. */

if ( arr7.includes('python')){
  htmlDocIdGet('p36').innerHTML += 'nous avons effectivement python dans notre array'
}



//***L’objet global Date et les dates en JavaScript***\\

//**Récupérer la date actuelle**\\

/* Pour récupérer la date actuelle sous forme littérale, on va tout simplement utiliser Date().
Pour afficher cette même date sous forme de nombre (le nombre de millisecondes 
écoulées depuis le 1er janvier 1970), on peut utiliser la méthode statique now() du 
constructeur Date. */

let date = Date();
let now = Date.now();
htmlDocIdGet('p37').innerHTML += date + '<br><br>';
htmlDocIdGet('p37').innerHTML += now;

//**Créer un objet de type date**\\

/* Pour créer un objet de type date, nous allons cette fois-ci être obligé d’utiliser le 
constructeur Date() avec donc le mot clef new. */

let dat = new Date(2025,06,30);
htmlDocIdGet('p38').innerHTML += dat;

//**Les méthodes getters et setters de l’objet Date**\\

/* De manière générale en programmation vous pouvez noter qu’on appelle les méthodes 
qui permettent d’obtenir / de récupérer quelque chose des « getters » (get signifie avoir, 
posséder en anglais). Ces méthodes sont souvent reconnaissables par le fait qu’elles 
commencent par get…(). */

/* De même, on appelle les méthodes qui permettent de définir quelque chose des « setters 
» (set signifie définir en anglais). Ces méthodes vont être reconnaissables par le fait 
qu’elles commencent par set…(). */

//*Les getters de l’objet Date*\\

/* Les getters suivants vont renvoyer un composant de date selon l’heure locale :
• getDay() renvoie le jour de la semaine sous forme de chiffre (avec 0 pour dimanche, 
1 pour lundi et 6 pour samedi) pour la date spécifiée selon l’heure locale ;
• getDate() renvoie le jour du mois en chiffres pour la date spécifiée selon l’heure 
locale ;
• getMonth() renvoie le numéro du mois de l’année (avec 0 pour janvier, 1 pour 
février, 11 pour décembre) pour la date spécifiée selon l’heure locale ;
• getFullYear() renvoie l’année en 4 chiffres pour la date spécifiée selon l’heure 
locale ;
• getHours() renvoie l’heure en chiffres pour la date spécifiée selon l’heure locale
• getMinutes() renvoie les minutes en chiffres pour la date spécifiée selon l’heure 
locale ;
• getSeconds() renvoie les secondes en chiffres pour la date spécifiée selon l’heure 
locale ;
• getMilliseconds() renvoie les millisecondes en chiffres pour la date spécifiée selon 
l’heure locale.*/

/* L’objet Date nous fournit également des getters équivalents qui vont cette fois-ci renvoyer 
un composant de date selon l’heure UTC et qui sont les suivants :
• getUTCDay() renvoie le jour de la semaine sous forme de chiffre (avec 0 pour 
dimanche, 1 pour lundi et 6 pour samedi) pour la date spécifiée selon l’heure UTC 
;
• getUTCDate() renvoie le jour du mois en chiffres pour la date spécifiée selon l’heure 
UTC ;
• getUTCMonth() renvoie le numéro du mois de l’année (avec 0 pour janvier, 1 pour 
février, 11 pour décembre) pour la date spécifiée selon l’heure UTC ;
• getUTCFullYear() renvoie l’année en 4 chiffres pour la date spécifiée selon l’heure 
UTC ;
• getUTCHours() renvoie l’heure en chiffres pour la date spécifiée selon l’heure UTC 
;
• getUTCMinutes() renvoie les minutes en chiffres pour la date spécifiée selon l’heure 
UTC ;
• getUTCSeconds() renvoie les secondes en chiffres pour la date spécifiée selon 
l’heure UTC ;
• getUTCMilliseconds() renvoie les millisecondes en chiffres pour la date spécifiée 
selon l’heure UTC. */

let date0 = new Date();
htmlDocIdGet('p39').innerHTML += ` jour de la semaine : ${date0.getDay()} ou ${date0.getUTCDay()}`;
htmlDocIdGet('p39').innerHTML += `<br><br> jour du mois actuelle : ${date0.getDate()} ou ${date0.getUTCDate()}`;
htmlDocIdGet('p39').innerHTML += `<br><br> mois de l'année : ${date0.getMonth()} ou ${date0.getUTCMonth()}`;
htmlDocIdGet('p39').innerHTML += `<br><br> année : ${date0.getFullYear()} ou ${date0.getUTCFullYear()}`;
htmlDocIdGet('p39').innerHTML += `<br><br> heures : ${date0.getHours()} ou ${date0.getUTCHours()}`;
htmlDocIdGet('p39').innerHTML += `<br><br> minutes : ${date0.getMinutes()} ou ${date0.getUTCMinutes()}`;
htmlDocIdGet('p39').innerHTML += `<br><br> secondes : ${date0.getSeconds()} ou ${date0.getUTCSeconds()}`;
htmlDocIdGet('p39').innerHTML += `<br><br> millisecondes : ${date0.getMilliseconds()} ou ${date0.getUTCMilliseconds()}`

//*Les setters de l’objet Date*\\

/* Les setters de l’objet Date vont nous permettre de définir (ou de modifier) des composants 
de dates pour une date donnée. Ces setters vont correspondre exactement aux getters 
vus précédemment (de manière générale, en programmation, les getters et les setters 
marchent par paires). */

/* • setDate() et setUTCDate() définissent le jour du mois en chiffres pour la date 
spécifiée selon l’heure locale ou l’heure UTC ;
• setMonth() et setUTCMonth() définissent le numéro du mois de l’année (avec 0 
pour janvier, 1 pour février, 11 pour décembre) pour la date spécifiée selon l’heure 
locale ou l’heure UTC ;
• setFullYear() et setUTCFullYear() définissent l’année en 4 chiffres pour la date 
spécifiée selon l’heure locale ou l’heure UTC ;
• setHours() et setUTCHours () définissent l’heure en chiffres pour la date spécifiée 
selon l’heure locale ou l’heure UTC ;
• setMinutes() et setUTCMinutes() définissent les minutes en chiffres pour la date 
spécifiée selon l’heure locale ou l’heure UTC ;
• setSeconds() et setUTCSeconds() définissent les secondes en chiffres pour la date 
spécifiée selon l’heure locale ou l’heure UTC ;
• setMilliseconds() et setUTCMilliseconds() définissent les millisecondes en chiffres 
pour la date spécifiée selon l’heure locale ou l’heure UTC. */

let dat0 = new Date();
dat0.setDate(20),dat0.setUTCDate(20);
dat0.setMonth(4),dat0.setUTCMonth(4);
dat0.setFullYear(2022),dat0.setUTCFullYear(2022);
dat0.setUTCHours(21),dat0.setHours(21);
dat0.setMinutes(51),dat0.setUTCMinutes(51);
dat0.setUTCSeconds(20),dat0.setSeconds(20);
htmlDocIdGet('p40').innerHTML += `date : ${dat0} `;

//**Convertir une date au format local**\\

/* Ces méthodes vont notamment nous permettre d’afficher les éléments de date dans un 
ordre local (jour puis mois puis année par exemple) ou de pouvoir afficher une heure selon 
un format 12 heures ou 24 heures. Elles vont également nous permettre de traduire des 
dates littérales anglaises dans la langue locale. */

/* Pour faire cela, on va pouvoir utiliser les 
méthodes toLocaleDateString(), toLocaleTimeString() et toLocaleString(). */

//La méthode toLocaleDateString() renvoie la partie « jour-mois-année » d’une date, formatée en fonction d’une locale et d’options.
//La méthode toLocaleTimeString() renvoie la partie « heures-minutes-secondes » d’une date, formatée en fonction d’une locale et d’options.
//La méthode toLocaleString() renvoie la date complète, formatée en fonction d’une locale et d’options.

/* Ces trois méthodes vont donc pouvoir prendre deux arguments : un premier argument qui 
est une locale et un second qui correspond à des options. */

/* Les options vont permettre de modifier le comportement par défaut de nos méthodes et 
notamment d’expliciter si on souhaite que la date passée soit renvoyée sous forme de 
chiffres ou sous forme littérale. */

/* Les options qui vont particulièrement nous intéresser vont être les suivantes :
• weekday qui représente le jour de la semaine. Les valeurs possibles sont 
« narrow », « short » et « long » ;
• day qui représente le jour du mois. Les valeurs possibles sont numeric et 2-digit ;
• month qui représente le mois. Les valeurs possibles sont numeric et 2-digit ;
• year qui représente l’année. Les valeurs possibles sont numeric et 2-digit ;
• hour qui représente l’heure. Les valeurs possibles sont numeric et 2-digit ;
• minute qui représente les minutes. Les valeurs possibles sont numeric et 2-digit ;
• second qui représente les secondes. Les valeur possibles sont numeric et 2-digit. */

/* A noter que les navigateurs sont obligés de supporter à minima les ensembles suivants. 
Si vous utilisez une autre combinaison, celle-ci pourra ne pas être supportée :
• weekday, year, month, day, hour, minute, second ;
• weekday, year, month, day ;
• year, month, day ;
• year, month ;
• month, day ;
• hour, minute, second ;
• hour, minute. */

//Une autre option intéressante est l’option timeZone qui permet de définir le fuseau horaire

let dateLocal = dat0.toLocaleString('fr-FR',{
  weekday:'long',
  year:'numeric',
  month:'long',
  day:'numeric',
  hour:'2-digit',
  minute:'numeric',
  second:'numeric'
});
htmlDocIdGet('p41').innerHTML += dateLocal;


//****BROWSER OBJECT MODEL(BOM)****\\

//***Introduction au Browser Object Model (BOM) et à l’objet Window***\\

/* Les objets suivants appartiennent au BOM et sont tous des enfants de Window :
• L’objet Navigator qui représente l’état et l’identité du navigateur et qu’on va utiliser 
avec l’API Geolocation ;
• L’objet History qui permet de manipuler l’historique de navigation du navigateur
• L’objet Location qui fournit des informations relatives à l’URL de la page courante ;
• L’objet Screen qui nous permet d’examiner les propriétés de l’écran qui affiche la 
fenêtre courante ;
• L’objet Document et le DOM dans son ensemble que nous étudierons en détail 
dans la suite */

//***Propriétés, méthodes et fonctionnement de l’objet Window***\\

//**Les propriétés de l’objet Window**\\

/* Pour le moment, nous allons simplement nous intéresser aux 
propriétés innerHeight, innerWidth, outerHeight et outerWidth. */

//Les propriétés outerHeight et outerWidth vont retourner la hauteur et la largeur de la fenêtre du navigateur en comptant les options du navigateur.
htmlDocIdGet('p42').innerHTML += `taile de la fenêtre extérieure(long×large) : ${window.outerHeight}×${window.outerWidth}`
//Les propriétés innerHeight et innerWidth vont retourner la hauteur et la largeur de la partie visible de la fenêtre de navigation (la partie dans laquelle le code est rendu).
htmlDocIdGet('p43').innerHTML += `taille de la fenêtre intérieure(long×large) : ${window.innerHeight}×${window.innerWidth}`

//**Les méthodes de Window**\\

//*Ouvrir, fermer, redimensionner ou déplacer une fenêtre*\\

//Ouvrir une fenêtre
//window.open(url,nom,elements de la taille de la fenêtre)
htmlDocIdGet('b1').addEventListener('click',() => window.open('http://localhost:7700/JS%20version%20fran%C3%A7aise/cours.html','','width=250px','height=250px'))
//méthode resizeBy():redimensionner en ajoutant ou en enlevant à sa taille actuelle un certain nombre de pixels
//méthode resizeTo():une nouvelle taille
//Chacune de ces deux méthodes va prendre deux arguments : une largeur et une hauteur et elles devront être appliquées sur la référence renvoyée par open().
/* Nous allons également pouvoir de la même façon déplacer la fenêtre sur un espace de 
travail avec les méthodes moveBy() qui va déplacer la fenêtre relativement à sa position 
de départ et moveTo() qui va la déplacer de manière absolue, par rapport à l’angle 
supérieur gauche de l’espace de travail.
Ces deux méthodes vont à nouveau prendre deux arguments qui correspondent au 
déplacement horizontal et vertical de la fenêtre. */
/* On va encore pourvoir faire défiler le document dans la fenêtre ouverte de manière relative 
ou absolue en utilisant les méthodes scrollBy() et scrollTo() qui vont prendre en argument 
le défilement horizontal et vertical à appliquer au document dans la fenêtre.
Bien évidemment, pour que ces deux méthodes aient un effet, il faut que le document soit 
plus grand que la fenêtre qui le contient c’est-à-dire qu’il y ait une barre de défilement dans 
celui-ci. */
/* Enfin, on va pouvoir fermer une fenêtre avec la méthode close(). */
htmlDocIdGet('b2').addEventListener('click',() => window.close('http://localhost:7700/JS%20version%20fran%C3%A7aise/cours.html','',''))

//*Afficher des boites de dialogue dans une fenêtre*\\

//alert(),prompt()
/* Pour rappel, la méthode alert() permet d’afficher une boite d’alerte tandis 
que prompt() affiche une boite de dialogue permettant aux utilisateurs de nous envoyer 
du texte. */
//confirm()
/* La méthode confirm(), quant-à-elle, ouvre une boite avec un message (facultatif) et deux 
boutons pour l’utilisateur : un bouton Ok et un bouton Annuler.
Si l’utilisateur clique sur « Ok », le booléen true est renvoyé par la fonction ce qui va donc 
nous permettre d’effectuer des actions en fonction du choix de l’utilisateur. */
//exemple
//htmlDocIdGet('b3').addEventListener('click',confirm('Fermer?')? () => window.close('http://localhost:7700/JS%20version%20fran%C3%A7aise/cours.html','',''):null)

//***Interface et objet Navigator et géolocalisation***\\

//**Les propriétés et méthodes de Navigator**\\

/* Les propriétés les plus intéressantes vont être les suivantes :
• language : retourne la langue définie dans le navigateur ;
• geolocation : retourne un objet Geolocation qui peut être utilisé pour définir la 
localisation de l’utilisateur ;
• cookieEnabled : détermine si les cookies sont autorisés ou non et 
retourne true ou false ;
• platform : retourne la plateforme utilisée par le navigateur. */
//language : retourne la langue définie dans le navigateur ;
//geolocation : retourne un objet Geolocation qui peut être utilisé pour définir la localisation de l’utilisateur ;
//cookieEnabled : détermine si les cookies sont autorisés ou non et retourne true ou false ;
//platform : retourne la plateforme utilisée par le navigateur.
htmlDocIdGet('p46').innerHTML += `langue du navigateur : ${navigator.language}<br> localisation : ${navigator.geolocation} <br>cookies permis? ${navigator.cookieEnabled? 'Oui':'non'}<br>palteforme utilisée : ${navigator.platform}`

//**L’interface et l’objet Geolocation**\\

//La méthode getCurrentPosition() permet d’obtenir la position actuelle de l’appareil en retournant un objet Position 
//La méthode watchPosition() permet de définir une fonction de retour qui sera appelée automatiquement dès que la position de l’appareil change.
/* Cette méthode 
retourne une valeur (un ID) qui va pouvoir être utilisé par la 
méthode clearWatch() pour supprimer la fonction de retour définie 
avec watchPosition() ; */
//La méthode clearWatch() est utilisée pour supprimer la fonction de retour passée à watchPosition().

/* La méthode getCurrentPosition() retourne un objet Position. L’interface Position ne 
dispose d’aucune méthode mais implémente deux propriétés : */
//Une propriété coords qui retourne un objet Coordinates avec les cordonnées de position de l’appareil ;
//Une propriété timestamp qui représente le moment où la position de l’appareil a été récupérée

/* L’interface Coordinates ne possède pas de méthodes mais implémente les propriétés 
suivantes : */
//•latitude qui représente la latitude de l’appareil ;
//• longitude qui représente la longitude de l’appareil ;
//• altitude qui représente l’altitude de l’appareil ;
//• accuracy qui représente le degré de précision (exprimé en mètres) des valeurs renvoyées par les propriétés latitude et longitude ;
//• altitudeAccuracy qui représente le degré de précision de la valeur renvoyée par la propriété altitude ;
//• heading qui représente la direction dans laquelle l’appareil se déplace. La valeur renvoyée est une valeur en degrés exprimée par rapport au Nord ;
//• speed qui représente la vitesse de déplacement de l’appareil ; vitesse exprimée en mètres par seconde.

//**Interface et objet History**\\

//*Les propriétés et méthodes de History*\\

/* L’interface History implémente plusieurs propriétés et méthodes qu’on va pouvoir utiliser 
à partir d’un objet History.
Les propriétés et méthodes qui vont nous intéresser sont les suivantes :
• La propriété length qui retourne la nombre d’éléments dans l’historique (en 
comptant la page actuelle), c’est-à-dire le nombre d’URL parcourues durant la 
session ;
• La méthode go() qui nous permet de charger une page depuis l’historique de 
session. On va lui passer un nombre en argument qui représente la place de la 
page qu’on souhaite atteindre dans l’historique par rapport à la page actuelle (-1 
pour la page précédente et 1 pour la page suivante par exemple) ;
• La méthode back() qui nous permet de charger la page précédente dans 
l’historique de session par rapport à la page actuelle. Utiliser back() est équivalent 
à utiliser go(-1) ;
• La méthode forward() qui nous permet de charger la page suivante dans 
l’historique de session par rapport à la page actuelle. Utiliser back() est équivalent 
à utiliser go(1). */

//**Interface et objet Location**\\

//*Les propriétés et méthode de l’objet Location*\\

/* Parmi les propriétés de Location, on peut notamment noter :
• hash, qui retourne la partie ancre d’une URL si l’URL en possède une ;
• search, qui retourne la partie recherche de l’URL si l’URL en possède une ;
• pathname, qui retourne le chemin de l’URL précédé par un / ;
• href, qui retourne l’URL complète ;
• hostname, qui retourne le nom de l’hôte ;
• port, qui retourne le port de l’URL ;
• protocole, qui retourne le protocole de l’URL ;
• host, qui retourne le nom de l’hôte et le port relatif à l’URL ;
• origin, qui retourne le nom de l’hôte, le port et le protocole de l’URL.
Ces propriétés sont assez peu utilisées de manière générale mais il reste bon de les 
connaître au cas où vous auriez besoin un jour de récupérer et de manipuler une URL ou 
une partie précise d’URL */

/* L’objet Location va également nous donner accès à 3 méthodes intéressantes :
• La méthode assign() qui va charger une ressource à partir d’une URL passée en 
argument ;
• La méthode reload() qui va recharger le document actuel ;
• La méthode replace() qui va remplacer le document actuel par un autre disponible 
à l’URL fournie en argument.
La différence fondamentale entre les méthodes assign() et replace() est qu’en 
utilisant assign(), on peut revenir en arrière pour revenir sur notre page de départ car celle-
ci a été sauvegardée dans l’historique de navigation ce qui n’est pas le cas si on choisit 
d’utiliser replace(). */

//**Interface et objet Screen**\\

//*Les propriétés et méthodes de l’objet Screen*\\

/* L’objet Screen nous donne accès à une grosse dizaine de propriétés dont 6 sont bien 
supportées par les navigateurs et particulièrement intéressantes : */
//• width : retourne la largeur totale de l’écran ;
//• availWidth : retourne la largeur de l’écran moins celle de la barre de tâches ;
//• height : retourne la hauteur totale de l’écran ;
//• availHeight : retourne la hauteur de l’écran moins celle de la barre de tâches ;
//• colorDepth : retourne la profondeur de la palette de couleur de l’écran en bits ;
//• pixelDepth : retourne la résolution de l’écran en bits par pixel.
/* Notez que si le navigateur ne peut pas déterminer les valeurs de colorDepth et 
de pixelDepth ou si il ne veut pas les retourner pour des raisons de sécurité, il doit 
normalement renvoyer « 24 ». */


//****Document Object Model(DOM)****\\

//***Les interfaces composant le DOM***\\

//Parmi les interfaces du DOM, quelques-unes vont particulièrement nous intéresser :
//• L’interface *Window* qu’on a déjà étudié et qui est liée au DOM ;
//• L’interface *Event* qui représente tout événement qui a lieu dans le DOM (nous allons définir précisément ce qu’est un évènement dans la suite de cette partie) ;
//• L’interface *EventTarget* qui est une interface que vont implémenter les objets qui peuvent recevoir des évènements ;
//• L’interface *Node* qui est l’interface de base pour une grande partie des objets du DOM ;
//• L’interface *Document* qui représente le document actuel et qui va être l’interface la plus utilisée ;
//• L’interface *Element* qui est l’interface de base pour tous les objets d’un document ;
/* En plus de ces interfaces incontournables, on pourra également citer les interfaces 
(mixin) ParentNode, ChildNode, NonDocumentTypeChildNode, HTMLElement et NonEleme
ntParentNode qui vont également nous fournir des propriétés et méthodes intéressantes */
//Pour bien vous situer dans la hiérarchie du DOM et entre ces interfaces, vous pouvez retenir que :

//• L’interface EventTarget est l’interface parent de Node et donc Node hérite (des propriétés et méthodes) de l’interface EventTarget ;
//• L’interface Node est le parent des interfaces Document et Element qui héritent donc de Node (et donc par extension également de EventTarget). De plus, Document et Element implémentent les mixin ParentNode et ChildNode ;
//• L’interface Element implémente également le mixin NonDocumentTypeChildNode ;
//• L’interface Document implémente également le mixin NonElementParentNode ;
//• L’interface HTMLElement hérite de l’interface Element.

//**Accès à un élément partant de son sélecteur CSS**\\

/* La méthode querySelector() retourne un objet Element représentant le premier élément 
dans le document correspondant au sélecteur (ou au groupe de sélecteurs) CSS passé 
en argument ou la valeur null si aucun élément correspondant n’est trouvé. */
/* La méthode querySelectorAll() renvoie un objet appartenant à l’interface NodeList. Les 
objets NodeList sont des collections (des listes) de nœuds. */
/* Pour itérer dans cette liste d’objets NodeList et accéder à un élément en particulier, on va 
pouvoir utiliser la méthode forEach(). Cette méthode prend une fonction de rappel en 
argument et cette fonction de rappel peut prendre jusqu’à trois arguments optionnels qui 
représentent :
• L’élément en cours de traitement dans la NodeList ;
• L’index de l’élément en cours de traitement dans la NodeList ;
• L’objet NodeList auquel forEach() est appliqué. */




























































































































































































































