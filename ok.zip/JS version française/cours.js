document.getElementById("p1").innerHTML = "enfin je réussi ce truc!!!";

//Opérateur ternaire et structure conditionnelle
function hide() {
  let pDisplay = document.getElementById("p4")
  pDisplay.style.display == 'block'? pDisplay.style.display = 'none': pDisplay.style.display = 'block'; //condition if?then:else;
}


//***Les Boucles***\\

//**Boucle while**\\
let x=0;
while (x<10){
  document.getElementById("p2").innerHTML += `x = ${x} <br>`
  x++;
}

let newg = document.getElementById("p3").innerHTML = '<a href="google.com">google</a>'

// **Boucle do...while** \\
let a = 15,b = 0;

//condition toujours vrai.
do{
    document.getElementById("p5").innerHTML += `b = ${b} <br>`;
  b++;
} while(b<10)
//condition non vérifiée mais s'exécute une fois
do {
    document.getElementById("p6").innerHTML += `a = ${a} <br>`;
  a++;
} while (a<10);

//**Boucle for**
for (let i=0;i<10;i++){
    document.getElementById("p7").innerHTML += `i = ${i} <br>`
};


//***Les Fonctions***\\

//**fonctions anonymes**\\

let anoFunc = function(){
  document.getElementById("p8").innerHTML = `ceci est une fonction
  anonyme`
};

anoFunc();

//**fonctions récursives**\\

/*Une fonction récursive est une fonction
qui va s’appeler elle-même au sein
de son code.*/

function recurs(t){
  if (t>0){
    document.getElementById('p9').innerHTML += `t = ${t} <br>`
    return recurs(t-1)
  } else{ return t }
};

recurs(15);



//****Programmation Orientée Objet(POO)****\\


//**Création d’un objet littéral**\\

/*Pour créer un objet littéral, on utilise une syntaxe utilisant une paire d’accolades { … } qui 
indique au JavaScript que nous créons un objet.*/

let obj = {
  nom: 'javascript',
  type: 'frontend',
  
  methode: function () {
   return `bonjour,ici c'est pour apprendre du ${this.nom} pour le developpement ${this.type}`
  }
};

/*Les membres d’un objet qui ne servent qu’à stocker des données sont appelés des 
propriétés tandis que ceux qui manipulent des données (c’est-à-dire ceux qui contiennent 
des fonctions en valeur) sont appelés des méthodes.*/

/*//*Utiliser le point pour accéder aux membres d’un objet, les 
modifier ou en définir de nouveaux*\\*/

/*Pour accéder aux propriétés et aux méthodes d’un objet, on utilise le caractère 
point . qu’on appelle également un accesseur. On va ici commencer par préciser le nom 
de l’objet puis l’accesseur puis enfin le membre auquel on souhaite accéder.
Cet accesseur va nous permettre non seulement d’accéder aux valeurs de nos différents 
membres mais également de modifier ces valeurs*/

//accès aux valeurs des propriétés
document.getElementById("p10").innerHTML = `langage : ${obj.nom} <br>`;
document.getElementById("p10").innerHTML += `type : ${obj.type}`;

/*j'ai remarqué que le signe += permet de 
créer une nouvelle ligne ou une 
nouvelle balise avec cette 
syntaxe js en l'ajoutant dans le même
cadre.c'est un peu comme créer une 
nouvelle balise <p id='p10'></p>
donc avec les mêmes propriétés*/

//appel de la méthode 'methode' avant modification des valeurs des propriétés 
document.getElementById("p12").innerHTML = obj.methode()+ "<br><br>";

//modification des valeurs des propriétés
obj.nom = 'python';
obj.type = 'backend';

document.getElementById("p11").innerHTML = `langage : ${obj.nom} <br>`;
document.getElementById("p11").innerHTML += `type : ${obj.type}`;

//appel des méthodes
//appel de la méthode 'methode' après modification des valeurs des propriétés 
document.getElementById("p12").innerHTML += obj.methode();


//***Définition et création d’un constructeur***\\

/*Un objet est un ensemble cohérent de propriétés et de méthodes.*/

//**La fonction construction d’objets : définition et création d’un constructeur**\\

/*Une fonction constructeur d’objets est une fonction qui va nous permettre de créer des 
objets semblables. En JavaScript, n’importe quelle fonction va pouvoir faire office de 
constructeur d’objets.*/

/*Pour construire des objets à partir d’une fonction constructeur, nous allons devoir suivre 
deux étapes : il va déjà falloir définir notre fonction constructeur et ensuite nous allons 
appeler ce constructeur avec une syntaxe un peu spéciale utilisant le mot clefs new.//appel de la méthode 'methode' avant modification des valeurs des propriétés 
*/

/*Dans une fonction constructeur, on va pouvoir définir un ensemble de propriétés et de 
méthodes. Les objets créés à partir de ce constructeur vont automatiquement posséder 
les (« hériter des ») propriétés et des méthodes définies dans le constructeur.
Comment une fonction peut-elle contenir des propriétés et des méthodes ? C’est très 
simple : les fonctions sont en fait un type particulier d’objets en JavaScript ! Comme tout 
autre objet, une fonction peut donc contenir des propriétés et des méthodes.*/

/*Notez que lorsqu’on définit un constructeur, on utilise par convention une majuscule au 
début du nom de la fonction afin de bien discerner nos constructeurs des fonctions 
classiques dans un script.*/

//**Créer des objets à partir d’une fonction constructeur**\\

function User(n,a,m,rD){
  //propriétés
  this.name = n;
  this.age = a;
  this.mail = m;
  this.registrationDate = rD;
  
  //méthode
  this.identity = function(){
    return `username: ${n};<br>
            age: ${a} years;<br>
            mail: ${this.mail};<br>
            member since: ${this.registrationDate}`
    /*on peut accéder aux valeurs des 
    propriétés soit directement avec leurs
    noms soit avec this.propriété*/
  }
}

/*En effet, l’idée d’un constructeur en JavaScript est de définir un plan de création d’objets. 
Comme ce plan va potentiellement nous servir à créer de nombreux objets par la suite, on 
ne peut pas initialiser les différentes propriétés en leur donnant des valeurs effectives, 
puisque les valeurs de ces propriétés vont dépendre des différents objets créés.*/

/*Le mot clef this est un mot clef qui apparait fréquemment dans les langages orientés 
objets. Dans le cas présent, il sert à faire référence à l’objet qui est couramment manipulé.
Pour le dire très simplement, c’est un prête nom qui va être remplacé par le nom de l’objet 
actuellement utilisé lorsqu’on souhaite accéder à des membres de cet objet.*/

/*utilité du mot clef this: 
Ce mot clef sert à représenter l’objet couramment utilisé. A chaque nouvel 
objet crée, il va être remplacé par l’objet en question et cela va nous permettre d’initialiser 
différemment chaque propriété pour chaque objet.*/

//*création d'un object*

/*Pour créer ensuite de manière effective des objets à partir de notre constructeur, nous 
allons simplement appeler le constructeur en utilisant le mot clef new. On dit également 
qu’on crée une nouvelle instance.*/

let yemo = new User("yemo",'21','yemodev@gmail.com','05 july 2025');

document.getElementById("p13").innerHTML += yemo.identity() + '<br>';
document.getElementById("p13").innerHTML += `nom d'utilisateur:  ${yemo.name}<br><br>`

/*Comme notre constructeur est une fonction, on va pouvoir l’appeler autant de fois qu’on 
le veut et donc créer autant d’objets que souhaité à partir de celui-ci et c’est d’ailleurs tout 
l’intérêt d’utiliser un constructeur. Chaque objet créé à partir de ce constructeur partagera 
les propriétés et méthodes de celui-ci.*/

//exemple
let stazy = new User("stazy",'34','stazyrypod@gmail.com','24 may 2019');
let kang = new User("kang",52,'kangdem@gmail.com','17 october 1997');
let samson = new User("samson",'63','samsamgo@gmail.com','07 february 2013');

document.getElementById("p13").innerHTML += stazy.identity() + '<br>';
document.getElementById("p13").innerHTML += `nom d'utilisateur:  ${stazy.name}<br><br>`
document.getElementById("p13").innerHTML += kang.identity() + '<br>';
document.getElementById("p13").innerHTML += `nom d'utilisateur:  ${kang.name}<br><br>`
document.getElementById("p13").innerHTML += samson.identity() + '<br>';
document.getElementById("p13").innerHTML += `nom d'utilisateur:  ${samson.name}<br>`

//**Constructeur et différenciation des objets**\\

/*La fonction constructeur doit vraiment être vue en JavaScript comme un plan de base pour 
la création d’objets similaires et comme un moyen de gagner du temps et de la clarté dans 
son code. On ne va définir dans cette fonction que les caractéristiques communes de nos 
objets et on pourra ensuite rajouter à la main les propriétés particulières à un objet.*/

//ajout d'une propriété spécifique à un objet donné
stazy.poids = 53;
document.getElementById(`p14`).innerHTML += stazy.identity() + '<br>';
document.getElementById(`p14`).innerHTML += 'poids: '+ stazy.poids + 'kg';
document.getElementById(`p14`).innerHTML += `<br> nom d'utilisateur:  ${stazy.name}<br><br>`


//NB::::::::::
/*je vais définir une fonction qui va prendre
en paramètre le numéro de l'id d'une balise
p après le p(p14 par exemple) pour simplifier
les document.get...ID('p14').innerHtml.
elle va s'appeler htlml()*/
function htmlDocIdGet(id){
  return document.getElementById(id)
}

//***Constructeur Object, prototype et héritage***\\

//**Le prototype en JavaScript orienté objet**\\

/*Dans les langages orientés objet utilisant des prototypes comme le JavaScript, tout est 
objet et il n’existe pas de classes et l’héritage va se faire au moyen de prototypes*/

/*les fonctions en JavaScript sont avant tout des 
objets. Lorsqu’on créé une fonction, le JavaScript va automatiquement lui ajouter une 
propriété prototype qui ne va être utile que lorsque la fonction est utilisée comme 
constructeur, c’est-à-dire lorsqu’on l’utilise avec la syntaxe new.
Cette propriété prototype possède une valeur qui est elle-même un objet. On parlera donc 
de « prototype objet » ou « d’objet prototype » pour parler de la propriété prototype.*/

/*Par défaut, la propriété prototype d’un constructeur ne contient que deux propriétés : une 
propriété constructor qui renvoie vers le constructeur contenant le prototype et une 
propriété __proto__ qui contient elle-même de nombreuses propriétés et méthodes.*/

/*Lorsqu’on crée un objet à partir d’un constructeur, le JavaScript va également ajouter 
automatiquement une propriété __proto__ à l’objet créé.
La propriété __proto__ de l’objet créé va être égale à la propriété __proto__ du constructeur 
qui a servi à créer l’objet.*/

//pratique
/*on avait eu à dire que la propriété poids
était spécifique pour un seul objet sur
lequel elle a été ajoutée*/

/*En fait, le contenu de la propriété prototype d’un constructeur va être partagé par tous les 
objets créés à partir de ce constructeur. Comme cette propriété est un objet, on va pouvoir 
lui ajouter des propriétés et des méthodes que tous les objets créés à partir du 
constructeur vont partager.
Cela permet l’héritage en orienté objet JavaScript. On dit qu’un objet « hérite » des 
membres d’un autre objet lorsqu’il peut accéder à ces membres définis dans l’autre objet.*/

/*Pour faire fonctionner cela en pratique, il faut se rappeler que la propriété prototype est 
un objet et qu’on va donc pouvoir lui ajouter des propriétés et des méthodes comme pour 
tout autre objet*/

//exemple
User.prototype.number = ' 90 90 50 40';
User.prototype.hi = function(){
  return `hello ${this.name}.<br> glad that we can call you on ${this.number}`
}
/*Ici, on ajoute une propriété number et une méthode hi() à la propriété prototype du 
constructeur User(). Chaque objet créé à partir de ce constructeur va avoir accès à 
cette propriété et à cette méthode.*/

//testons avec de nouveaux objets

let def = new User('david',23,'dev@yahoo.fr','06 march 2024');
let dev = new User('john',43,'johv@yahoo.fr','12 april 2004');

htmlDocIdGet('p15').innerHTML += '<br>' + def.identity() + '<br>';
htmlDocIdGet('p15').innerHTML += `numéro: (+001)${dev.number} <br>`;
htmlDocIdGet('p15').innerHTML += '<br>' + dev.identity() + '<br>';
htmlDocIdGet('p15').innerHTML += `numéro: (+001)${dev.number} <br>`;
htmlDocIdGet('p15').innerHTML += '<br>'+ def.hi()+'<br>';
htmlDocIdGet('p15').innerHTML += '<br>'+ dev.hi();

/*Définir des propriétés et des méthodes dans le prototype d’un constructeur nous permet 
ainsi de les rendre accessible à tous les objets créés à partir de ce constructeur sans que 
ces objets aient à les redéfinir.*/

/*Pour avoir le code le plus clair et le plus performant possible, nous définirons donc 
généralement les propriétés des objets (dont les valeurs doivent être spécifiques à l’objet) 
au sein du constructeur et les méthodes (que tous les objets vont pouvoir appeler de la 
même façon) dans le prototype du constructeur.*/


//**Mise en place d’une hiérarchie d’objets avec héritage en JavaScript**\\

/*Quel intérêt à faire cela ? Parfois, nous voudrons créer des types d’objets relativement 
proches. Plutôt que de redéfinir un constructeur entièrement à chaque fois, il va être plus 
judicieux de créer un constructeur de base qui va contenir les propriétés et méthodes 
communes à tous nos objets puis des constructeurs plus spécialisés qui vont hériter de 
ce premier constructeur.*/

/*Pour mettre en place un héritage ou plus exactement un système de délégation (qui est 
un mot beaucoup plus juste que le terme « héritage » dans le cas du JavaScript), nous 
allons toujours procéder en trois étapes :
1. On va déjà créer un constructeur qui sera notre constructeur parent ;
2. On va ensuite un constructeur enfant qui va appeler le parent ;
3. On va modifier la __proto__ de la propriété prototype de l’enfant pour qu’elle soit 
égale au parent.*/

/*Pour information, la méthode call() permet d’appeler une fonction rattachée à un objet 
donné sur un autre objet. La méthode call() est une méthode prédéfinie qui appartient au 
prototype de l’objet natif Function.*/

//ça risque d'être dur

function Ligne(longueur){
  this.longueur = longueur;
}

Ligne.prototype.distance = function (){
  return document.getElementById("p16").innerHTML = `distance: ${this.longueur} m <br>`;
};

function Rectangle(longueur,largeur){
  Ligne.call(this,longueur);
  /*On l’utilise ici pour faire appel au constructeur Ligne() dans notre constructeur Rectangle(). 
Le mot clef this permet de faire référence à l’objet courant et de passer la valeur de l’objet 
relative à sa propriété longueur.*/
  this.largeur = largeur;
}
/*Pour information, la méthode call() permet d’appeler une fonction rattachée à un objet 
donné sur un autre objet. La méthode call() est une méthode prédéfinie qui appartient au 
prototype de l’objet natif Function.*/
Rectangle.prototype = Object.create(Ligne.prototype);
/*il va nous falloir rétablir la valeur de la 
propriété constructor de prototype de Rectangle car la ligne précédente a eu pour effet de 
définir Rectangle.prototype.constructor comme étant égal à celui de Ligne().*/
Rectangle.prototype.constructor = Rectangle;
Rectangle.prototype.aire = function (){
  return htmlDocIdGet('p16').innerHTML += `Aire: ${this.longueur*this.largeur} m² <br>`;
};

/*On répète l’opération en création un deuxième niveau d’héritage avec le 
constructeur Parallélépipède() qui va hériter de Rectangle().*/
function parallelepipede(longueur,largeur,hauteur){
  Rectangle.call(this,longueur,largeur);
  this.hauteur = hauteur;
}

parallelepipede.prototype = Object.create(Rectangle.prototype);
parallelepipede.prototype.constructor = parallelepipede;
parallelepipede.prototype.volume = function(){
  return htmlDocIdGet("p16").innerHTML += `volume: ${this.longueur*this.largeur*this.hauteur} m³`;
}

/*Enfin, on crée un objet geo à partir du constructeur Parallélépipède(). Cet objet va pouvoir 
utiliser les méthodes définies dans les prototypes de Parallélépipède(), de Rectangle() et 
de Ligne() !*/
let geo = new parallelepipede(10,5,3);
geo.distance();
geo.aire();
geo.volume();

//***Les classes en orienté objet JavaScript***\\

/*Une classe est un plan général qui va servir à créer des objets similaires. Le code d’une 
classe va généralement être composé de propriétés et de méthodes dont vont hériter les 
objets qui vont être créés à partir de la classe.*/

/*Une classe va également contenir une méthode constructeur qui va être appelée
automatiquement dès qu’ on va créer un objet à partir de notre classe et va nous permettre
d’ initialiser les propriétés d’ un objet.*/

/*Il existe de grandes différences conceptuelles entre les langages orientés objet basés sur 
les classes et ceux bases sur les prototypes. On peut notamment noter les suivantes :
• Dans les langages basés sur les classes, tous les objets sont créés en instanciant 
des classes ;
• Une classe contient toutes les définitions des propriétés et méthodes dont dispose 
un objet. On ne peut pas ensuite rajouter ou supprimer des membres à un objet 
dans les langages basés sur les classes ;
• Dans les langages basés sur les classes, l’héritage se fait en définissant des 
classes mères et des classes étendues ou classes enfants.*/

//**Création d’une classe et d’objets en JavaScript**\\

//NB:: 
/*Nous n'avons pas besoin de préciser
'function' devant notre constructeru et devant
nos méthodes*/

class Cube{
  constructor(longueur,largeur,hauteur){
    this.longueur = longueur;
    this.largeur = largeur;
    this.hauteur = hauteur;
  }
  
  volume(){
     htmlDocIdGet('p17').innerHTML += ` volume : ${this.longueur*this.largeur*this.hauteur} m³`
  }
}
//création d'un objet avec la classe Cube
let cal = new Cube(10,5,3)
cal.volume()

//**Classes étendues et héritage en JavaScript**\\

/*Pour étendre une classe, c’est-à-dire pour créer une classe enfant qui va hériter des 
propriétés et des méthodes d’une classe parent, nous allons utiliser le mot clef extends*/

//exemple de class enfant
class Rectangles extends Cube{
  /*La chose à savoir ici est que nous devons utiliser le mot clef super() qui permet d’appeler 
le constructeur parent dans le constructor() de notre classe fille afin que les propriétés 
soient correctement initialisées.*/
  constructor(longueur,largeur){
    super(longueur,largeur); //appel des propriétés parents
  /*si rectangle avait plus de propriétés
  que la classe parent Cube,alors les 
  propriétés de surplus sont aussi
  instanciées avec this.propriété après le
  super(propriétéParent1,propriétéParent2,..,propriétéParentn)*/
  }
  
  aire(){
    htmlDocIdGet('p18').innerHTML += `Aire: ${this.longueur*this.largeur} m²`
  }
}

//création d'un objet héritier
let test = new Rectangles(20,35);
test.aire();

















