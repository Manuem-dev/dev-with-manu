//syntaxe:
//(arguments) => valeur à retourner

function somme(a,b){
  return console.log(a + b)
}

let somme0 = (a,b) => console.log(a+b)

somme(2,4)
somme0(2,4)

/*Les fonctions fléchées, cependant, sont différentes des autres fonctions au sens où elles 
ne possèdent pas de valeur propre pour 'this' : si on utilise ce mot clef dans une fonction 
fléchée, alors la valeur utilisée pour celui-ci sera celle du contexte de la fonction fléchée 
c’est-à-dire celle de la fonction englobante.*/
