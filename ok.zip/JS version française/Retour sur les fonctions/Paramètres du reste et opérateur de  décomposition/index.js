//**Les paramètres du reste**\\

//servent à définir des fonctions avec un nombre variable d'arguments

//Pour faire cela, nous allons devoir utiliser une notation utilisant '…' dans la déclaration des paramètres de la fonction suivi d’un nom qu’on va choisir

function somme(...nbr){
  let s = 0;
  for (let nb of nbr){
    s+=nb
  }
  return console.log(s)
}

//Littéralement, on demande au JavaScript de stocker les arguments passés dans un tableau(Array []) qui possèdera le nom mentionné après …

//On va également pouvoir créer des fonctions en précisant des paramètres de manière « classique » et en utilisant aussi des paramètres du reste. Dans ce cas-là, seuls les arguments supplémentaires passés à la fonction seront stockés dans le tableau.
function user(nom,prenom,...surnoms){
  let sur = '';
  for (let name of surnoms){
    sur += name;
  }
  return console.log(`info:\n nom : ${nom}\n prénom : ${prenom}\n surnom(s) : ${sur}\n`)
  //pour que ce type d’écriture fonctionne, il faudra toujours préciser les paramètres classiques en premier et les paramètres du reste en dernier dans la déclaration de la fonction.
}

//**L’opérateur de décomposition**\\

//Les paramètres du reste permettent de stocker une liste d’arguments dans un tableau qu’on va ensuite pouvoir manipuler.

//L’opérateur de décomposition permet de faire l’opération inverse, à savoir transformer un tableau en une liste d’arguments qu’on va pouvoir passer à une fonction.

//L’opérateur de décomposition utilise la même syntaxe avec '…' que les paramètres du reste à la différence qu’on va faire suivre les trois points par le nom d’un tableau existant.

let arr = [3,4,5,1,2,54,23,135,54];
function sum(...arrays){
  let som = 0;
  for (let tb of arrays){
    som += tb
  }
  return console.log(som)
}
















