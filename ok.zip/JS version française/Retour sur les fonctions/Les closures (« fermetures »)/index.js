/* On appelle closure (ou « fermeture » en français) une fonction interne qui va pouvoir 
continuer d’accéder à des variables définies dans la fonction externe à laquelle elle 
appartient même après que cette fonction externe ait été exécutée. */

/* On a pu noter que les fonctions internes ont accès aux variables définies dans la fonction 
externe et peuvent les utiliser durant son exécution. Le contraire n’est cependant pas vrai: la fonction externe n’a aucun moyen d’accéder aux variables définies dans une de ses 
fonctions internes. */
/* Placer des variables dans une fonction interne permet donc de les sécuriser en empêchant 
leur accès depuis un contexte externe. Cela peut être très lorsqu’on souhaite définir des 
propriétés dont la valeur ne doit pas être modifiée par n’importe qui. */

//**Les closures en pratique**\\

//Une closure est une fonction interne qui va « se souvenir » et pouvoir continuer à accéder à des variables définies dans sa fonction parente même après la fin de l’exécution de celle-ci.

function compt(){
  let count = 0;
  return function (){
    return count++
  }
}

console.log(compt()) //cela retourne plutôt la fonction interne que la valeur qu'elle return

let plus = compt()
console.log(plus())
console.log(plus())
console.log(plus())

// donc permet une protection de count la variable externe