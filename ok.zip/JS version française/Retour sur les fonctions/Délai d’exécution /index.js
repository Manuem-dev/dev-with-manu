//Parfois, on ne voudra pas exécuter une fonction immédiatement mais plutôt dans un certain temps ou on pourra encore vouloir exécuter une fonction plusieurs fois avec un intervalle de temps défini entre chaque exécution

/* Cela va notamment être le cas lors de la création d’une horloge, d’un slider, ou d’une 
animation comportant un défilement en JavaScript . */

//**La méthode setTimeout()**\\

//La méthode setTimeout() permet d’exécuter une fonction ou un bloc de code après une certaine période définie (à la fin de ce qu’on appelle un « timer »).

//Il va falloir passer deux arguments à cette méthode : une fonction à exécuter et un nombre en millisecondes qui représente le délai d’exécution de la fonction (le moment où la fonction doit s’exécuter à partir de l’exécution de setTimeout()).
//On va également pouvoir passer des arguments facultatifs à setTimeout() qui seront passés à la fonction qui doit s’exécuter après un certain délai

timeoutId = setTimeout(alert/*fonction ou méthode à exécuter*/,2000/*temps avabt l'exécution*/,'timeout set à 2000ms(2s)'/*argument de la fonction oubde la méthode à exécuter*/);

//NB::Notez que la méthode setTimeout() renvoie un entier positif à l’issue de son exécution qui va identifier la timer créé par l’appel à setTimeout(). On va ainsi pouvoir utiliser cet entier pour annuler l’exécution de la fonction à laquelle on a ajouté un délai avec clearTimeout() qu’on va étudier par la suite.

document.getElementById('btn0').addEventListener('click',() => timeoutId)

//**La méthode clearTimeout()**\\

//La méthode clearTimeout() va nous permettre d’annuler ou de supprimer un délai défini avec setTimeout() (et donc également d’annuler l’exécution de la fonction définie dans setTimeout()).

//Pour que cette méthode fonctionne, il va falloir lui passer en argument l’identifiant retourné par setTimeout().

document.getElementById('btn1').addEventListener('click',() => clearTimeout(timeoutId))


//**La méthode setInterval()**\\

//La méthode setInterval() permet d’exécuter une fonction ou un bloc de code en l’appelant en boucle selon un intervalle de temps fixe entre chaque appel.

//Cette méthode va prendre en arguments le bloc de code à exécuter en boucle et l’intervalle entre chaque exécution exprimé en millisecondes.
//On va également pouvoir passer en arguments facultatifs les arguments de la fonction qui doit être exécutée en boucle.

//NB::Tout comme la méthode setTimeout(), la méthode setInterval() renvoie un entier positif qui va servir à identifier un appel à setInterval() et nous permettre d’annuler l’intervalle de répétition avec clearInterval().

//Donc même caractéristiques que setTimeout()

/* La méthode setInterval() va s’avérer très utile et être beaucoup utilisée pour réaliser de 
nombreuses choses sur un site. On va notamment pouvoir l’utiliser pour afficher une 
horloge qui va se mettre à jour automatiquement toutes les secondes */

interval = setInterval(function(){
  let d = new Date();
  document.getElementById('p1').innerHTML = d.toLocaleTimeString();
  
},1000) //cela permet d'afficher l'heure qui se met à jour après une seconde(1000ms)

document.getElementById('btn2').addEventListener('click',() => interval);

//**La méthode clearInterval()**\\

//La méthode clearInterval() permet d’annuler l’exécution en boucle d’une fonction ou d’un bloc de code définie avec setInterval().

//Pour que cette méthode fonctionne, il va falloir lui passer en argument l’identifiant retourné par setInterval().

document.getElementById('btn3').addEventListener('click',() => clearInterval(interval));



