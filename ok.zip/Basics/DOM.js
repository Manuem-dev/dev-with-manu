//*** The Dociment Object Model(DOM)***\\\



//**the Browser Object Model(BOM)***\\

/*The console.dir() method shows a list of all the properties of the specified object. 
You can click on the little triangles to open the objects and inspect them even more.
*/

console.dir(window);

//*Window history object*\\

/*This object is actually what you can use to go back to a previous page. It has a built-
in function for that called go
*/

console.dir(window.history);

//*Window navigator object*\\

/*This property is particularly interesting because it contains information about the browser we are 
using, such as what browser it is and what version we are using, and what operating 
system the browser is running on. 
This can be handy for customizing the website for certain operating systems. Imagine 
a download button that will be different for Windows, Linux, and macOS.
*/

console.dir(navigator);

//*Window location object*\\

/*This contains the URL of the current web page. If you override (parts of) that 
property, you force the browser to go to a new page! 
*/

console.dir(location);


//**The DOM**\\


//*Additional DOM properties*\\

console.dir(document)

//*Selecting page elements*\\

/*To select page elements to use within your JavaScript code and in order to 
manipulate elements, you can use either the querySelector() or querySelectorAll()
method. Both of these can be used to select page elements either by tag name, ID, or 
class.
*/
/*The document.querySelector() method will return the first element within the 
document that matches the specified selectors. If no matching page elements are 
found, the result null is returned. To return multiple matching elements, you can 
use the method document.querySelectorAll().

The querySelectorAll() method will return a static NodeList, which represents a 
list of the document's elements that match the specified group of selectors
*/















































































































































































































































































































