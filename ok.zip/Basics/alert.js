//***Built-in***\\



//**Global Methods**\\


/*The global JavaScript methods can be used without referring to the built-in object 
they are part of. This means that we can just use the method name as if it is a 
function that has been defined inside the scope we are in, without the "object" in 
front of it.*/
let exemple = 5;
console.log(isNaN(exemple)); /*or*/ console.log(Number.isNaN(exemple));
/*here Number is the class in which insNaN is defined*/



//**Decoding and encoding URIs**\\


/*Sometimes you will need to encode or decode a string. Encoding is simply 
converting from one shape to another. In this case we will be dealing with percent 
encoding, also called URL encoding. Before we start, there might be some confusion 
on the URI and URL meaning. A URI (uniform resource identifier) is an identifier of 
a certain resource. URL (uniform resource locator) is a subcategory of URI that is not 
only an identifier, but also holds the information on how to access it (location).*/

//*decodeUri() and encodeUri()*\\
let uri = "https://www.hidev.netify.com/submit?name= yemo stazy yemos";
let encode_uri = encodeURI(uri);
console.log('encoded : ',encode_uri);
console.log('decoded : ', decodeURI(encode_uri))
/* they aren't usefull for the moment,
because skip some things like ?,+...
but the right way is 👇🏽👇🏽👇🏽
*/
/*So, the methods decodeURI() and encodeURI() can be very useful to fix a broken URI, 
but they are useless when you only want to encode or decode a string that contains a 
character with a special meaning, such as = or &*/

//*decodeUriComponent() and encodeUriComponent()*\\
let uris = uri.concat(" obj+meth&prop=js-5 this=slt&prop-meth");
let encode_uris = encodeURIComponent(uris);
console.log('encoded : ',encode_uris);
console.log('decoded : ', decodeURIComponent(encode_uris))



//**Parsing numbers**\\


//*Making integers with parseInt()*\\

/*
With the method parseInt() a string will be changed to an integer.
*/
let x = '5';
console.log(typeof x);
let y = 3;
console.log(typeof y);
let t = parseInt(x);
console.log(typeof t);
z = t + y ;
console.log(z,' is a ',typeof z);

let hi = 7.8;
let hy = "7.8";
console.log(parseInt(hy),'\n', parseInt(hi));//like math.floor


//*Making floats with parseFloat()*\\

/*Similarly, we can use parseFloat() to parse a string to a float
*/

let flt = '6.2';
console.log(parseFloat(flt),' is a ',typeof parseFloat(flt));
let flo = 6.2;
let fl = 6.2

flo == flt?console.log('are equal'):console.log('not equal');

/*if we use === it'lk log not equal due to the type of the variables
string and number
but with ==,it just convert all to the same
type and evaluate them*/

console.log(flo === fl);
console.log(flo === flt);
console.log(flo === parseFloat(flt));


//**Array methods**\\


//*Performing a certain action for every item*\\

let array = ['hello','hi','howdy','javascript','python'];

function elmt(element,index) {
    console.log('element at position ',index,' is ',element);
};

array.forEach(elmt);

//*Filtering an array*\\

/*We can use the built-in filter() method on an array to alter which values are in the 
array. The filter method takes a function as an argument, and this function should 
return a Boolean. If the Boolean has the value true, the element will end up in the 
filtered array. If the Boolean has the value false, the element will be left out.
*/

let arrays = ["nine",5,3,19,'one',true,['hi','hello',4,155,true],{val: 2,val2: "str"},true,false,true];
let string = (element,index) => typeof element === 'string';//the name 'string' is important
console.log(arrays.filter(string));
console.log(arrays.filter(element => typeof element === 'number'));
console.log(arrays.filter(element => typeof element === 'object'));
console.log(arrays.filter(element => typeof element === 'boolean'));
console.log(arrays[6].filter(element => typeof element === 'number'));
console.log(arrays.every(string));
/*You can use the every() method to see whether something is true for all elements 
in the array. If that is the case, the every() method will return true, else it will 
return false
*/

//*Mapping the values of an array*\\

/*
Sometimes you'll need to change all the values in an array. With the array map()
method you can do just that. This method will return a new array with all the new 
values. You'll have to say how to create these new values. This can be done with the 
arrow function. It is going to execute the arrow function for every element in the 
array
*/

let arr0 = [1,2,3,4,5];
console.log(arr0.map(x => x+1));
let utilisateurs = [
    { nom: "Alice", age: 25 },
    { nom: "Bob", age: 30 },
    { nom: "Charlie", age: 35 }
];
   
let noms = utilisateurs.map(utilisateur => utilisateur.nom);
console.log(noms);


//**String methods**\\


//*Converting a string to an array*\\

let lg = 'language is javascript';
let lgArray = lg.split(''); //transform each letter to an array element
let lgArr = lg.split(' '); //create an array element when meet a ' '(space)
let lgarray = lg.split('a'); //create an array element when meet the 'a'
console.log(lgArray);
console.log(lgArr);
console.log(lgarray);

//*Converting an array to a string*\\

let str0 = lgArray.join();
let str1 = lgArray.join(''); // join all array's elements with nothing between them
let str2 = lgarray.join('a') // join all array's elements with 'a'
console.log(str0);
console.log(str1);
console.log(str2);

//*Working with index and positions*\\

let greet = 'hello javascript';
console.log(greet.indexOf('java'));
console.log(greet.indexOf('python')); //not found will log -1
if (greet.indexOf('java') != -1){ console.log("java is different to javascript")};

/*the indexOf() method is returning the index of the first occurrence, 
but similarly, we also have a lastIndexOf() method. It returns the index where the 
argument string occurs last. 
*/

//get index with character in string
console.log(greet.lastIndexOf('a'));
console.log(greet.indexOf('a'));

/*Sometimes you will have to do the reverse; instead of looking for what index a string 
occurs at, you will want to know what character is at a certain index position. This is 
where the charAt(index) method comes in handy, where the specified index position 
is taken as an argument
*/

//get character with index in string
console.log(greet.charAt(13));

//*Creating substrings*\\

/*With the slice(start, end) method we can create substrings. This does not alter the 
original string, but returns a new string with the substring. It takes two parameters, 
the first is the index at which it starts and the second is the end index. If you leave 
out the second index it will just continue until the end of the string from the start. 
The end index is not included in the substring
*/

let str3 = 'just python and javascript for web';
console.log(str3.slice(5));
console.log(str3.slice(5,11));

//*Replacing parts of the string*\\

/*If you need to replace a part of the string, you can use the replace(old, new)
method. It takes two arguments, one string to look for in the string and one new 
value to replace the old value with
*/

let str4 = " here is python";
console.log(str4.replace('python','javascript'));

/*This will log to the console Hi Pascal. If you don't capture the result in a variablr, it is gone, 
because the original string will not get changed. If the string you are targeting 
doesn't appear in the original string, the replacement doesn't take place and the 
original string will be returned
*/

//*Uppercase and lowercase*\\

/*We can change the letters of a string with the toUpperCase() and toLowerCase()
built-in methods on string
*/

let str5 = 'javascript';
const str6 = 'PYTHON';
console.log(str5.toUpperCase());
console.log(str6.toLowerCase());

let caps = "HI HOW ARE YOU?";

let cplx0 = caps.toLowerCase().split('')[0].toUpperCase().concat(caps.toLowerCase().slice(1));
//or
let cplx1 = caps
    .toLowerCase()
    .split('')[0]
    .toUpperCase()
    .concat(caps.toLowerCase().slice(1));
//or
let cap = "HI HOW ARE YOU?";
let fixed_caps = cap.toLowerCase();
let first_capital = fixed_caps.charAt(0).toUpperCase().concat(fixed_caps.slice(1));
console.log(cplx0)
console.log(cplx1)
console.log(first_capital);

//*The start and end of a string*\\

let hello = "Say hello";
console.log(hello.startsWith("Say"));
if (hello.toLowerCase().startsWith('say') == true){ console.log("Hello 👋🏾👋🏾👋🏾")};

let mail = 'exemple@gmail.com';
if (mail.toLowerCase().endsWith('gmail.com')){console.log('is the good mail')}


//**Number methods**\\


//*Checking if something is (not) a number*\\

const num0 = 5;
const num1 = '5'; // is a number even though is a number string
console.log(isNaN(num0));
console.log(isNaN(num1));

//*Specifying a number of decimals*\\

let toRound = 2.15572773838
console.log(toRound.toFixed(3)); // is like a troncature


//**Math methods**\\


//*Finding the highest and lowest number*\\

console.log(Math.max(2,7,43,987,432));
console.log(Math.min(2,-755,43,865));
console.log(Math.max('hi',5));

//*Square root and raising to the power of*\\

console.log(Math.sqrt(121));
console.log(Math.pow(3,4));

//*Turning decimals into integers*\\

//normal round
console.log(Math.round(5.6533));
console.log(Math.round(5.2364));

//round up
console.log(Math.ceil(7.1));
console.log(Math.ceil(8.9));
console.log(Math.ceil(-7.2));
console.log(Math.ceil(-3.9));

//round down
console.log(Math.floor(7.1));
console.log(Math.floor(8.9));
console.log(Math.floor(-7.2));
console.log(Math.floor(-3.9));

//integer part round
console.log(Math.trunc(7.1));
console.log(Math.trunc(8.9));
console.log(Math.trunc(-7.2));
console.log(Math.trunc(-3.9));


//**Date methods**\\


//*Creating dates*\\

/*One way to create dates is by using the 
different constructors.
*/
let date = Date();
let dt = new Date().g
console.log(date,dt);

/*There is a 
built-in method, now(), that returns the current date and time, similar to what the no 
argument constructor does
*/

console.log(Date.now());

//*Methods to get and set the elements of a date*\\

console.log("day : ",new Date().getDay(),'\n',
            "day of month : ", new Date().getDate(),'\n',
            "month : ",new Date().getUTCMonth(),'\n',
            "Year : ", new Date().getFullYear(),'\n',
            "hour : ", new Date().getHours(),'\n',
            "time : ", new Date().getTime(),'\n',
);

//*Parsing dates*\\

console.log(Date.parse('6/7/2025'),'\n',
            Date.parse('june 7,2025')
);

//*Converting a date to a string*\\

console.log(new Date().toDateString(),'\n',
            new Date().toLocaleDateString()
)   


//+++practice+++
function scramble(imyString){
    let newString = '';
    let myString = imyString;
    while (myString.length != 0){
        let random = Math.floor(Math.random()*myString.length);
        newString = newString.concat(myString.charAt(random));
        console.log(newString);
        myString = myString.replace(myString.charAt(random),'');
        myString.length-=1
    }
    console.log("initial string : " ,imyString,'\n',
                "scrambled string : " ,newString)   
}
scramble('javascript');




































































