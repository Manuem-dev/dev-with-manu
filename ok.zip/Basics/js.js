//*****POO*****

//***Un objet en général***

let obj = {
    //**Propriétés**(stockent des données)**
    nom: 'javascript',
    list: [1,3,4,5,9],
    
    //**Méthodes(manipulent les données)**
    met: function () {//fonction anonyme
          let greet = 'hello '+this.nom+' '+this.list[3];
          return console.log(greet)
    }
    
}
//accès à la valeur de l'objet
obj.met();























